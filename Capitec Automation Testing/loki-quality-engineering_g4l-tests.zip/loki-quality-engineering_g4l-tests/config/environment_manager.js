const config = {
  api: {
    url: ''
  },
  database: {
    host: "",
    port: 5432,
    username: "",
    password: "",
    name: "",
  },
  ui: {
    url: "",
  },
};

switch (process.env.ENV) {
  case 'dev':
    config.api.url = "https://api.dev.example.com/v1";
    config.database.host = "localhost";
    config.database.username = "db_user";
    config.database.password = "db_password";
    config.database.name = "my_database";
    config.ui.url = "https://capitec.co.za";
    break;

  case 'int':
    config.api.url = "https://api.int.example.com/v1";
    config.database.host = "localhost";
    config.database.username = "db_user";
    config.database.password = "db_password";
    config.database.name = "my_database";
    config.ui.url = "https://capitec.co.za";
    break;

  case 'qa':
    config.api.url = "https://api.qa.example.com/v1";
    config.database.host = "localhost";
    config.database.username = "db_user";
    config.database.password = "db_password";
    config.database.name = "my_database";
    config.ui.url = "https://capitec.co.za";
    break;

  default:
  // throw new Error(`Unknown environment: `);
}

module.exports = config;