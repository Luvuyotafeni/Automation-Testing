// @ts-check
const messageCache = new Map(); // topic => [messages]

/**
 * Default message handler that parses and caches Kafka messages by topic.
 *
 * Converts the message's key, value, and headers to strings (with `value` JSON-parsed),
 * adds metadata like partition, and stores the result in an in-memory cache grouped by topic.
 *
 * @param {string} topic - The Kafka topic the message was received from.
 * @param {import('kafkajs').KafkaMessage} message - The Kafka message object.
 * @param {number} partition - The partition number the message was received from.
 */
function defaultJsonCacheReceiver(topic, message, partition) {
  const parsed = {
    key: message.key?.toString(),
    value: message.value ? JSON.parse(message.value.toString()) : {},
    headers: Object.fromEntries(
      Object.entries(message.headers || {}).map(([k, v]) => [k, v?.toString()])
    ),
    partition: partition,
  };

  if (!messageCache.has(topic)) {
    console.log(`Adding cache for topic: ${topic}`);
    messageCache.set(topic, []);
  }

  messageCache.get(topic).push(parsed);
}

function findMessage(topic, key, headers = {}, partition) {
  const messages = messageCache.get(topic) || [];

  return messages.find((msg) => {
    const hasKey = msg.key.includes(key);
    const hasHeaders =
      !headers ||
      Object.entries(headers).every(([k, v]) => msg.headers[k] === v);
    const hasPartition = partition == null ? true : msg.partition === partition;

    return hasKey && hasHeaders && hasPartition;
  });
}

/**
 * Waits for a Kafka message to appear in the message cache that matches the given criteria.
 * It polls the cache until a matching message is found or a timeout occurs.
 *
 * A message matches if:
 * - The `key` is a substring of the message's key.
 * - All specified `headers` (if any) exactly match the message's headers.
 * - The `partition` (if provided) matches the message's partition.
 *
 * @param {string} topic - The Kafka topic to search within.
 * @param {string} key - Substring to match against the message key.
 * @param {Object<string, string>} [headers] - Optional headers to match. All specified headers must match exactly.
 * @param {number} [partition] - Optional partition to match. If omitted, messages from any partition are considered.
 * @param {number} [timeoutMs=10000] - Maximum time to wait (in milliseconds) before giving up.
 * @param {number} [checkIntervalMs=50] - Interval (in milliseconds) between successive checks.
 * @returns {Promise<{
 *   key: string,
 *   value: any,
 *   headers: Record<string, string>,
 *   partition: number
 * } | undefined>} A matching message object, or `undefined` if no match is found within the timeout.
 */
async function waitForMessage(
  topic,
  key,
  headers,
  partition,
  timeoutMs = 10000,
  checkIntervalMs = 50
) {
  const deadline = Date.now() + timeoutMs;
  return new Promise((resolve, reject) => {
    const interval = setInterval(() => {
      const found = findMessage(topic, key, headers, partition);
      if (found) {
        clearInterval(interval);
        console.log(`Match found in ${topic}[${found.partition}]:`);
        console.log(`\tMessage Key: ${found.key}`);
        console.log(`\tHeaders: ${JSON.stringify(headers)}\n`);
        return resolve(found);
      }
      if (Date.now() > deadline) {
        clearInterval(interval);
        reject(
          new Error(
            `Timed out waiting for message on topic '${topic}' with key '${key}' and headers: ${headers}`
          )
        );
      }
    }, checkIntervalMs);
  });
}

function clearDefaultJsonCache() {
  messageCache.clear();
}

module.exports = {
  clearDefaultJsonCache,
  findMessage,
  defaultJsonCacheReceiver,
  waitForMessage,
};
