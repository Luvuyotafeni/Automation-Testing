import { request, expect } from '@playwright/test';
const config = require('../config/environment_manager.js');

export const apiRequest = {
  /**
   * GET request using Axios
   * @param {string} url - The URL to send the GET request to
   * @param {object} options - Optional config (headers, params, etc.)
   * @returns {Promise<any>} - The response data or an error
   */
  getCall: async function (url, options = {}) {
    try {
      let context = await request.newContext();
      const response = await context.get(url, options);
      return response;
    } catch (error) {
      console.error('Error in fetchData:', error);
      throw error; // Rethrow to handle it where the function is used
    }
  },

  Get: async function (url, token) {
    let context = await request.newContext();
    let response = await context.get(url, {
      headers: {
        'Accept': '*/*',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      ignoreHTTPSErrors: true
    });

    let Body = await response.text();
    return Body;

  },

  /**
   *  POST request using Axios
   * @param {string} url - The URL to send the POST request to
   * @param {object} options - Optional config (headers, etc.)
   * @returns {Promise<any>}
   */
  postCall: async function (url, options = {}) {
    try {
      let context = await request.newContext();
      const response = await context.post(url, options);
      return response;
    } catch (error) {
      console.error('Error in postData:', error);
      throw error;
    }
  },

  /**
   * PUT request using Axios
   * @param {string} url - The URL to send the PUT request to
   * @param {object} options - Optional config (headers, etc.)
   * @returns {Promise<any>}
   */
  putCall: async function (url, options = {}) {
    try {
      let context = await request.newContext();
      const response = await context.put(url, options);
      return response;
    } catch (error) {
      console.error('Error in putData:', error);
      throw error;
    }
  }

};

function convertToJson(rawResponse) {
  try {
    // First check if the response is already a JSON object
    const parsed = JSON.parse(rawResponse);

    // If parsed is already an object (not an array), return it directly
    if (!Array.isArray(parsed)) {
      return parsed;
    }

    // If it's an array, process it as before
    const result = {};
    parsed.forEach(item => {
      // Case 1: string like "Key - Value"
      if (typeof item === 'string') {
        const [key, ...rest] = item.split(' - ');
        const value = rest.join(' - ');
        if (key !== undefined) {
          result[String(key).trim()] = String(value ?? '').trim();
        }
        return;
      }

      // Case 2: tuple-like [key, value]
      if (Array.isArray(item) && item.length >= 2) {
        const [k, v] = item;
        if (typeof k === 'string') {
          result[k] = v;
        }
        return;
      }

      // Case 3: object -> merge its properties
      if (item && typeof item === 'object') {
        Object.assign(result, item);
        return;
      }

      // Fallback: store by index
      const idx = Object.keys(result).length;
      result[idx] = item;
    });

    return result;
  } catch (error) {
    console.error('Error parsing response:', error);
    throw error;
  }
}