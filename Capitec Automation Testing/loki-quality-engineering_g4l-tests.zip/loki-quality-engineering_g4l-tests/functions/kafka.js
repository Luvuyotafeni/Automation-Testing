// @ts-check
const { getAWSCredentials } = require("../external/aws/aws-sdk-v3");
const { Kafka, logLevel } = require("kafkajs");
const {
  generateAuthTokenFromCredentialsProvider,
} = require("aws-msk-iam-sasl-signer-js");
const {
  defaultJsonCacheReceiver,
  clearDefaultJsonCache,
} = require("./kafka-message-cache");

// #############################################################################
// can add custom compression types here and register the codec
// https://kafka.js.org/docs/1.14.0/producing#compression
// #############################################################################

let consumer = null;
let isRunning = false;

/**
 * Creates and configures a KafkaJS client using AWS IAM credentials and OAUTHBEARER authentication.
 *
 * @param {import("@aws-sdk/client-sts").Credentials} credentials - AWS IAM credentials.
 * @param {string} kafkaClientId - Unique client ID for KafkaJS client.
 * @param {string[]} kafkaBrokers - Array of Kafka broker addresses.
 * @param {string} awsRegion - AWS region.
 * @param {import("kafkajs").logLevel} kafkaLogLevel - Kafka client log level.
 * @returns {Promise<Kafka>} A configured KafkaJS client instance.
 *
 * @throws Will throw an error if token generation fails.
 */
async function getKafkaClient(
  credentials,
  kafkaClientId,
  kafkaBrokers,
  awsRegion,
  kafkaLogLevel = logLevel.ERROR
) {
  return new Kafka({
    logLevel: kafkaLogLevel,
    clientId: kafkaClientId,
    brokers: kafkaBrokers,
    ssl: true,
    sasl: {
      mechanism: "oauthbearer",
      oauthBearerProvider: async () => {
        const authTokenResponse =
          await generateAuthTokenFromCredentialsProvider({
            region: awsRegion,
            awsCredentialsProvider: () =>
              Promise.resolve({
                accessKeyId: credentials.AccessKeyId,
                secretAccessKey: credentials.SecretAccessKey,
                sessionToken: credentials.SessionToken,
              }),
          });
        return { value: authTokenResponse.token };
      },
    },
  });
}

/**
 * Starts a Kafka consumer and caches received messages by topic.
 *
 * @param {string} awsRegion - AWS region for credentials.
 * @param {string} awsRoleArn - AWS IAM Role ARN for authentication.
 * @param {string} awsWebIdentityTokenFileLocation - Path to the web identity token file.
 * @param {string[]} kafkaBrokers - List of Kafka broker addresses.
 * @param {string[]} topics - List of topics to subscribe to.
 * @param {string} [kafkaClientId="playwright-client"] - Kafka client ID.
 * @param {string} [groupId="playwright-test-group"] - Consumer group ID.
 * @param {import("kafkajs").logLevel} kafkaLogLevel - Kafka client log level.
 * @param {(topic: string, message: import('kafkajs').KafkaMessage, partition: number) => void} messageReceiver - Method called for each received message
 */
async function startConsumer(
  awsRegion,
  awsRoleArn,
  awsWebIdentityTokenFileLocation,
  kafkaBrokers,
  topics,
  kafkaClientId = "playwright-client",
  groupId = "playwright-test-group",
  kafkaLogLevel = logLevel.ERROR,
  messageReceiver = defaultJsonCacheReceiver
) {
  if (isRunning) return;

  const creds = await getAWSCredentials(
    awsRegion,
    awsRoleArn,
    awsWebIdentityTokenFileLocation
  );
  const client = await getKafkaClient(
    creds,
    kafkaClientId,
    kafkaBrokers,
    awsRegion,
    kafkaLogLevel
  );
  consumer = client.consumer({ groupId });

  await consumer.connect();
  console.log(`Consumer connected to group ${groupId}`);
  await consumer.subscribe({ topics: topics, fromBeginning: true });
  console.log(`Consumer subscribed to topics:\n\t${topics}\n`);

  await consumer.run({
    eachMessage: async ({ topic, message, partition }) =>
      messageReceiver(topic, message, partition),
  });

  isRunning = true;
}

async function stopConsumer() {
  if (!isRunning) return;
  await consumer.disconnect();
  console.log("Consumer disconnected");

  isRunning = false;
  consumer = null;

  clearDefaultJsonCache();
}

module.exports = {
  getKafkaClient,
  startConsumer,
  stopConsumer,
};
