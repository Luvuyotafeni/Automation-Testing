const { faker } = require('@faker-js/faker');
const { expect } = require('@playwright/test');
require("dotenv").config();

let totalPixels;

module.exports = {

  convertToJson: async function (rawResponse) {
    try {
      // First check if the response is already a JSON object
      const parsed = JSON.parse(rawResponse);

      // If parsed is already an object (not an array), return it directly
      if (!Array.isArray(parsed)) {
        return parsed;
      }

      // If it's an array, process it as before
      const result = {};
      parsed.forEach(item => {
        const [key, value] = item.split(' - ');
        result[key] = value;
      });

      return result;
    } catch (error) {
      console.error('Error parsing response:', error);
      throw error;
    }
  }

};
