const { test, expect} = require('@playwright/test');
require('dotenv').config();

//npx playwright test

/**
 * add extra information for case
 * @owner Jensen
 * @jira MCR-16888
 * @browserstack TC-122
 */

test('Example Arithmetic Test', { tag: ['@Negative'] }, async () => {
    // Define numbers to be used in the test
    const numOne = 5;
    const numTwo = 3;

    // Calculate the sum
    const total = numOne + numTwo;
    console.log(`The sum of numOne and numTwo is ${total}`);

    // Validate the sum
    expect.soft(total).toBe(8);

    // This expect is intentionally incorrect to test negative cases
    expect.soft(total).toBe(5);
});