const { test, expect} = require('@playwright/test');
const { Client } = require('pg');
require('dotenv').config();
const fs = require('fs');
const path = require('path');

/**
 * add extra information for case
 * @owner Jensen
 * @jira MCR-16889
 * @browserstack TC-123
 */
 test('Example Rest API Test GET & POST', { tag: ['@Negative'] }, async ({request}) => {
    // Define endpoints
    const getUsersEndpoint = 'https://reqres.in/api/users?page=2';
    const createUserEndpoint = 'https://reqres.in/api/users';

    // GET Request
    const getResponse = await request.get(getUsersEndpoint);
    expect.soft(getResponse.ok()).toBeTruthy();
    const users = await getResponse.json();
    console.log("GET api response:", users);
    // Validate GET response
    expect.soft(users.data.length).toBeGreaterThan(0);
    expect.soft(users.page).toBe(4);
    // New user data
    const newUser = {
        name: "Luffy",
        job: "Pirate"
    };
    
    // POST Request
    const postResponse = await request.post(createUserEndpoint, { data: newUser });
    expect.soft(postResponse.ok()).toBeTruthy();
    const user = await postResponse.json();
    console.log("POST api response:", user);
    // Validate POST response
    expect.soft(user.name).toBe('Luffy2');
});

/**
 * @owner Jensen
 * @jira MCR-16890
 */
test('GET Users without API key returns authentication error', { tag: ['@Negative'] }, async ({request}) => {
    const getUsersEndpoint = 'https://reqres.in/api/users?page=2';

    const getResponse = await request.get(getUsersEndpoint);
    const responseBody = await getResponse.json();
    console.log("GET api response (missing key):", responseBody);

    expect.soft(responseBody.error).toBe('missing_api_key');
    expect.soft(responseBody.message).toBe('The x-api-key header is required for this endpoint.');
    expect.soft(responseBody.hint).toContain('Create a free key');
    expect.soft(responseBody.next_steps.length).toBeGreaterThan(0);
    expect.soft(responseBody.docs_url).toBe('https://app.reqres.in/docs#authentication');
    expect.soft(responseBody._meta.powered_by).toBe('ReqRes');
    expect.soft(responseBody._meta.context).toBe('invalid_key');
});