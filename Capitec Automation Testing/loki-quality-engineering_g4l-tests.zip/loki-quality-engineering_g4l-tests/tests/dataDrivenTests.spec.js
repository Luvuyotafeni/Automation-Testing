const { test, expect} = require('@playwright/test');
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse/sync');
const { setMetadata } = require('monocart-reporter');



//npx playwright test <testfile name>



const testData = [
    { name: 'Luffy', job: 'Pirate', testnum: 'Test 5: ', owner: 'Jensen', browserstack: 'TC-226',tag : '@Positive' },
    { name: 'Zoro', job: 'Swordsman', testnum: 'Test 6: ', owner: 'Jensen', browserstack: 'TC-227',tag : '@Positive' },
    { name: 'Sanji', job: 'Chef', testnum: 'Test 7: ', owner: 'Jensen', browserstack: 'TC-228',tag : '@Positive' }
];


test.describe('Data Driven Tests JSON', () => {
    testData.forEach((data) => {
        test(`${data.testnum} Example Data Driven Test from JSON`,{tag: data.tag} ,async ({ request }) => {
            setMetadata({ owner: data.owner, browserstack: data.browserstack}, test.info());

            // Make a POST request with the test data
            const response = await request.post('https://reqres.in/api/users', { data });
            expect.soft(response.ok()).toBeTruthy();

            // Parse the response
            const user = await response.json();
            console.log("API response:", user);

            // Validate the response
            expect.soft(user.name).toBe(data.name);
        });
    });
});





// Read and parse the CSV file
const records = parse(fs.readFileSync(path.join(__dirname, 'testDataExample.csv')), {
    columns: true,
    delimiter: ';',
    from : 1, //start from row
    to : 500, //end at row 
    skip_empty_lines: true
});


test.describe('Data Driven Tests CSV', () => {
    for (const record of records) {
     
        test(`${record.test_case} : Example Data Driven Test From CSV`,{tag: `@${record.tags}`} , async () => {
           setMetadata({ owner: record.owner, browserstack: record.browserstack , jira : record.jira }, test.info());
            // Log the record details
            console.log(`Test number: ${record.test_case}`);
            console.log(`CIF number: ${record.cif_number}`);
            console.log(`Account number: ${record.account_number}`);
            console.log(`Total: ${record.total}`);

            if(record.test_case == 'Test 1' || record.test_case == 'Test 10')
            {
                test.fail();
            }

            // Additional test logic can be added here if necessary
        });
    }
});
