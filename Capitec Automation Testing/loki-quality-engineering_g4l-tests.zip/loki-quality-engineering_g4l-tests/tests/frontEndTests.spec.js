const { test, expect} = require('@playwright/test');
const { Client } = require('pg');
require('dotenv').config();
const { setMetadata } = require('monocart-reporter');

//npx playwright test --browser=chromium --headed


/**
 * add extra information for case
 * @owner Jensen
 * @jira MCR-16889
 * @browserstack TC-125 
 */
test('Example UI Test', { tag: ['@Positive'] }, async ({page}, testInfo) => {
    // Navigate to the Playwright website
    await page.goto('https://playwright.dev/');

    // Click the "Get started" link
    await page.getByRole('link', { name: 'Get started' }).click();

    // expect.soft the page to have a heading with the text "Installation"
    await expect.soft(page.getByRole('heading', { name: 'Installation' })).toBeVisible();

    // Take a screenshot of the page
    const screenshot = await page.screenshot({ fullPage: true });
    await testInfo.attach('screenshot', {
        body: screenshot,
        contentType: 'image/png'
    });
});
