const { test, expect} = require('@playwright/test');
const config = require('../config/environment_manager');
//npx playwright test

/**
 * this test demonstrates how to run your tests against different environments
 * config is set depending on the environment variable that you set
 * @owner Jensen
 * @jira MCR-16888
 */

//Use the commands below to run the tests on different environments
 //ENV=dev npx playwright test tests/test-on-different-environments.spec.js
 //ENV=int npx playwright test tests/test-on-different-environments.spec.js
 //ENV=qa npx playwright test tests/test-on-different-environments.spec.js

test('Example Test On DEV', { tag: ['@Positive'] }, async () => {
    console.log("Running test on :" , process.env.ENV);
    console.log(config.api.url);
});

