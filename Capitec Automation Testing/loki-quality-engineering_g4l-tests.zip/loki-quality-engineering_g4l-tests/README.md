# Product Engineering Playwright Testing Template

This repository provides a template for running tests using Playwright.

## What is Playwright?

Playwright is a Node.js library. It can be used for various testing scenarios, including end-to-end testing, integration testing, and unit testing. https://playwright.dev/docs/intro

## Features

- Cross-browser testing with Chromium, Firefox, and WebKit
- API testing capabilities
- Mobile app testing integration via WebdriverIO Remote
- BrowserStack App Automate support for real device testing
- Unified test reporting
- Parallel and sequential test execution options

## Mobile App Testing Integration

This template includes support for testing native mobile applications using WebdriverIO Remote and BrowserStack App Automate, all within your existing Playwright test framework. No need to switch to an entirely new framework or spawn separate processes. This integration allows you to:

- Run API and mobile app tests sequentially in a single process
- Share data between API and mobile test steps
- Leverage BrowserStack's real device cloud for iOS and Android testing
- Use your existing Playwright infrastructure and reporting
- Continue using your existing test runner and reporting tools

### How the Integration Works

The integration uses WebdriverIO's `remote()` function to create a WebDriver session directly within a Playwright test. This allows you to control mobile devices without switching to a separate test framework or spawning separate processes.

```javascript
// The key integration point:
const driver = await remote(wdioOptions);
```

This creates a standalone WebDriver session that can control a mobile device directly from your Playwright test.

### Key Benefits

- **Framework Continuity**: Maintain your investment in existing Playwright tests
- **Unified Reporting**: All tests report through the same mechanism
- **Sequential Testing**: Run API tests before mobile tests with proper dependencies
- **Data Sharing**: Pass results from API tests to mobile tests
- **Resource Efficiency**: Everything runs in the same Node.js process
- **Simplified CI/CD**: No need for complex orchestration between frameworks

## Getting Started

### Prerequisites

- Node.js 16 or higher
- A BrowserStack account for real device testing (for mobile app tests)
- Your iOS or Android app uploaded to BrowserStack (for mobile app tests)

### Installation

1. Clone this template repository
2. Install dependencies:
   ```
   npm install
   ```
3. Set up environment variables (create a `.env` file):
   ```
   BROWSERSTACK_USERNAME=your_username
   BROWSERSTACK_ACCESS_KEY=your_access_key
   API_BASE_URL=your_api_base_url
   ```

### Running Tests

To run all tests:
```
npx playwright test
```

To run only mobile tests:
```
npx playwright test path-to-your-test
```


## Example Mobile Test

```javascript
const { test } = require('@playwright/test');
const { remote } = require('webdriverio');
require('dotenv').config();

test.describe.serial('iOS App Test Suite', () => {
  // Share data between tests
  let apiTestData;
  
  // First test: API Test
  test('API Test - Setup Data', async ({ request }) => {
    // Get data from an API that will be used in mobile test
    const response = await request.get('/api/endpoint');
    apiTestData = await response.json();
    console.log('API test data:', apiTestData);
  });
  
  // Second test: Mobile Test using WebdriverIO remote
  test('WebdriverIO iOS Mobile Test', async () => {
    // Initialize WebdriverIO session with BrowserStack
    const driver = await remote({
      hostname: 'hub-eu-only.browserstack.com',
      user: process.env.BROWSERSTACK_USERNAME,
      key: process.env.BROWSERSTACK_ACCESS_KEY,
      capabilities: {
        deviceName: 'iPhone 15',
        platformVersion: '17',
        platformName: 'ios',
        app: 'bs://your-app-id',
        projectName: "Your Project Name",
        buildName: "Your Build Name",
        debug: true,
        networkLogs: true
      },
      logLevel: 'info',
      waitforTimeout: 30000,
      connectionRetryTimeout: 90000,
      connectionRetryCount: 3,
    });
    
    try {
      // Handle system dialogs like notifications if they appear
      try {
        const allowButton = await driver.$('//XCUIElementTypeButton[@name="Allow"]');
        if (await allowButton.isDisplayed()) {
          await allowButton.click();
        }
      } catch (e) {
        console.log('No notification dialog found');
      }
      
      // Use data from API test in your mobile test
      await driver.$('~input-field').setValue(apiTestData.value);
      await driver.$('~submit-button').click();
      
      // Additional test steps...
    } catch (error) {
      // Take screenshot on failure
      const screenshot = await driver.takeScreenshot();
      require('fs').writeFileSync(`error-${Date.now()}.png`, screenshot, 'base64');
      throw error;
    } finally {
      // Always clean up the session
      await driver.deleteSession();
    }
  });
});
```

## Example Kafka Test

Install the required kafka npm packages:

```sh
npm i kafkajs aws-msk-iam-sasl-signer-js
```

Set your config variables preferably in `config/environment_manager.js`:

```js
config = {
  // other properties
  awsRoleArn: process.env.AWS_ROLE_ARN,
  awsWebIdentityTokenFileLocation: process.env.AWS_WEB_IDENTITY_TOKEN_FILE,
  awsRegion: process.env.AWS_REGION,
  kafkaBrokers: ["broker1", "broker2", "broker3"],
}
```

The default kafka consumer group uses an in-memory, JSON-parsed message cache on a topic level.

### Usage

```js
const { startConsumer, stopConsumer } = require("../functions/kafka");

// start the consumer in a beforeAll hook
test.beforeAll(async () => {
  await startConsumer(
    config.awsRegion,
    config.awsRoleArn,
    config.awsWebIdentityTokenFileLocation,
    config.kafkaBrokers,
    [
      "topicA",
      "topicB"
    ],
  );
});

// stop in a afterAll hook
test.afterAll(async () => {
  await stopConsumer(); // this will clear the cache
});
```

The consumer will build up the cache in the background. To test for messages that are received:

```js
const { waitForMessage } = require("../functions/kafka-message-cache");

// in a test
test("some test", async () => {
  // other API calls or Playwright assertions

  let msg = await waitForMessage("topicA", "some-message-key");
})
```

Some defaults are set but they can all be tweaked by setting the appropriate function parameters:

* `kafkaClientId` = "playwright-client"
* `groupId` = "playwright-test-group"
* `kafkaLogLevel` = logLevel.ERROR
* `timeoutMs` = 10000 --> timeout after failing to receive message
* `checkIntervalMs` = 50 --> checks the cache every 50ms for a received message

### Matching messages
```js
// based on key
let msg = await waitForMessage("topicA", "some-message-key");

// based on key and headers
let msg = await waitForMessage("topicA", "some-message-key", { header1: true });

// based on key and partition
let msg = await waitForMessage("topicA", "some-message-key", undefined, 1);
```

### Customization

```js
// bring your own message receiver implementation
await startConsumer(
  // other parameters
  (topic, message, partition) => {} // your own receiver
);
```

You can add your own compression Codec in `./functions/kafka.js` at the top of the file. See [examples](https://kafka.js.org/docs/1.14.0/producing#compression).

## Best Practices

- Use Page Objects for both web and mobile tests
- Implement dynamic waits instead of fixed delays
- Take screenshots on test failures
- Handle permission dialogs and other system popups

## Configuration Options

See `playwright.config.js` for available configuration options, including:
- Timeouts
- Retries
- Reporter settings
- Parallelization options
- Screenshot and trace settings

## Advanced Usage

### Handling System Dialogs

```javascript
// Handle iOS notification permissions
try {
  const allowButton = await driver.$('//XCUIElementTypeButton[@name="Allow"]');
  if (await allowButton.isDisplayed()) {
    await allowButton.click();
  }
} catch (e) {
  console.log('No notification dialog found');
}
```

### Taking Screenshots on Failure

```javascript
try {
  // Test steps...
} catch (error) {
  const screenshot = await driver.takeScreenshot();
  require('fs').writeFileSync('error.png', screenshot, 'base64');
  throw error;
}
```

## Resources

- [Playwright Documentation](https://playwright.dev/docs/intro)
- [WebdriverIO Documentation](https://webdriver.io/docs/api)
- [BrowserStack App Automate](https://www.browserstack.com/app-automate)


## Using VAULT to store sensitive data

example endpoint
https://<vault-url>/path-to-your-key
https://vault.server/v1/kv/subkeys/product/domain/stubby/dev



READ

```sh
curl -k --location 'https://path-to-your-secret' \
	--header 'X-Vault-Token: <vault-token>' \
	--header 'Content-Type: application/json'
```


WRITE

```sh
curl -k \
    -H "X-Vault-Token: <vault-token>" \
    -H "Content-Type: application/json" \
    -X POST \
 	-d '-d '{"data":{"username":"test_user","password":"test_password"}}' \' \
curl -k --location 'https://path-to-your-secret' \
```


## Feel free to explore and adapt this template to suit your testing needs using Playwright.
