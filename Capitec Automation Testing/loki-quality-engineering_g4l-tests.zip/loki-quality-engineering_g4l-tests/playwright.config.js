const { defineConfig } = require('@playwright/test');
import browserstack from './external/browserstack/browserstack.js';
import slackWebhook from './external/slack/slack-web-api.js';
const path = require('path');
process.env.CI ? require('./external/vault/set-variables') : null;
const fs = require('fs');

//Decide if you want to publish results to slack and browserstack
const publish_reports = false;
//Publish results to BrowserStack
const browserstack_toggle = publish_reports;
//Publish results to Slack
const slack_toggle = publish_reports;
//Determines whether you running github-runner or browser-stack yml
const isAppJob = process.env.CI === 'true' && process.env.TARGET === 'app';

/**
 * @see https://playwright.dev/docs/test-configuration
 */

module.exports = defineConfig({
  timeout: 300 * 1000, // if youre running mobile app tests you need to extend this window
  testDir: './tests',
  testIgnore: process.env.CI === 'true' && !isAppJob ? ['app/**'] : [], // ignore 'app' unless it's the target - set in browserstack yml file
  /* Run tests in files in parallel */
  fullyParallel: true,
  /* Fail the build on CI if you accidentally left test.only in the source code. */
  //forbidOnly: !!process.env.CI,
  /* Retry on CI only */
  retries: process.env.CI ? 0 : 0,
  /* Opt out of parallel tests on CI. */
  workers: 1,
  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
  reporter: [['line'], ['monocart-reporter', {
    name: "Playwright Test Report",
    outputFile: 'test-results/report.html',
    onEnd: async (reportData, helper) => {
      console.log("Injecting custom CSS into generated HTML report...");

      const reportPath = path.join(process.cwd(), "test-results", `report.html`); //Path to your monocart report
      let reportContent = fs.readFileSync(reportPath, "utf8");

      // Define custom CSS for resizing images
      const customCSS = `
      <style>
        img {
          max-width: 600px !important;
          max-height: 500px !important;
          display: block;
          margin: auto;
        }
      </style>
    `;

      // Inject CSS before the closing </head> tag
      reportContent = reportContent.replace("</head>", `${customCSS}</head>`);

      // Save the updated report
      fs.writeFileSync(reportPath, reportContent, "utf8");

      console.log("Custom CSS injected successfully!");

      browserstack_toggle ? await browserstack(reportData, helper) : null;
      slack_toggle ? await slackWebhook(reportData, helper) : null;

    },
    tags: {
      'Positive': {
        style: {
          background: '#008000'
        },
        description: 'This is a positive test'
      },
      'Negative': {
        style: {
          background: '#d00'
        },
        description: 'This is a negative test'
      }
    },


    // custom columns
    columns: (defaultColumns) => {

      // disable title tags
      defaultColumns.find((column) => column.id === 'title').titleTagsDisabled = true;

      // add tags column
      const index = defaultColumns.findIndex((column) => column.id === 'type');
      defaultColumns.splice(index, 0, {
        // define the column in reporter
        id: 'owner',
        name: 'Owner',
        align: 'center',
        searchable: true,
        styleMap: {
          'font-weight': 'normal'
        }
      },
        {
          // another column for JIRA link
          id: 'jira',
          name: 'JIRA #',
          width: 100,
          searchable: true,
          styleMap: 'font-weight:normal;',
          formatter: (v, rowItem, columnItem) => {
            const key = rowItem[columnItem.id];
            return `<a href="https://your-jira-url/${key}" target="_blank">${v}</a>`;
          },
        },
        {
          id: 'tags',
          name: 'Tags',
          width: 150,
          formatter: 'tags'
        }
      );



    }
  }]],
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {
    ignoreHTTPSErrors: true,
    /* Base URL to use in actions like `await page.goto('/')`. */
    // baseURL: 'http://127.0.0.1:3000',

    /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */
    //trace: 'on-first-retry',
  },

  /* Configure projects for major browsers */
  //projects: [
  // {
  //   name: 'chromium',
  //   use: { ...devices['Desktop Chrome'] },
  // },

  // {
  //   name: 'firefox',
  //   use: { ...devices['Desktop Firefox'] },
  // },

  // {
  //   name: 'webkit',
  //   use: { ...devices['Desktop Safari'] },
  // },

  /* Test against mobile viewports. */
  // {
  //   name: 'Mobile Chrome',
  //   use: { ...devices['Pixel 5'] },
  // },
  // {
  //   name: 'Mobile Safari',
  //   use: { ...devices['iPhone 12'] },
  // },

  /* Test against branded browsers. */
  // {
  //   name: 'Microsoft Edge',
  //   use: { ...devices['Desktop Edge'], channel: 'msedge' },
  // },
  // {
  //   name: 'Google Chrome',
  //   use: { ...devices['Desktop Chrome'], channel: 'chrome' },
  // },
  //],

  /* Run your local dev server before starting the tests */
  // webServer: {
  //   command: 'npm run start',
  //   url: 'http://127.0.0.1:3000',
  //   reuseExistingServer: !process.env.CI,
  // },
});

