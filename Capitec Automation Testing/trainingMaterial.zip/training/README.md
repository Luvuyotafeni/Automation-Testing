# Automation Training - Playwright Framework

Welcome to the automation testing training program. This training is built around the team's Playwright framework and teaches you everything you need to write, run, and maintain automated tests from scratch.

---

## Prerequisites

Before starting, make sure you have:
- Node.js 16+ installed (`node --version`)
- The framework cloned and dependencies installed (`npm install`)
- A code editor (VS Code recommended)

---

## Training Modules

| Module | Topic | Difficulty |
|--------|-------|------------|
| [01 - Getting Started](./module-01-getting-started/guide.md) | Test structure, running tests, assertions | Beginner |
| [02 - API Testing](./module-02-api-testing/guide.md) | GET/POST requests, response validation | Beginner |
| [03 - UI Testing](./module-03-ui-testing/guide.md) | Browser navigation, locators, screenshots | Beginner |
| [04 - Data-Driven Testing](./module-04-data-driven-testing/guide.md) | JSON & CSV data sources, dynamic tests | Intermediate |
| [05 - Environment Config](./module-05-environment-config/guide.md) | Multi-environment setup, .env files | Intermediate |
| [06 - Helper Functions](./module-06-helper-functions/guide.md) | Reusable functions, module patterns | Intermediate |
| [07 - Reporting](./module-07-reporting/guide.md) | Monocart reporter, metadata, tags, steps | Intermediate |

---

## How to Use This Training

Each module contains:
1. **`guide.md`** — A written explanation of the concept with code examples
2. **`exercises/`** — Hands-on coding exercises for you to complete
3. **`exercises/solution-XX.spec.js`** — Reference solutions (try the exercise first!)

### Running exercises

From the root of the framework, run a specific exercise file:
```bash
npx playwright test training/module-01-getting-started/exercises/exercise-01.spec.js
```

Or run all training exercises at once:
```bash
npx playwright test training/
```

---

## Learning Path

Work through the modules **in order** — each one builds on the previous.

> **Tip:** The best way to learn is to try writing the exercise yourself before looking at the solution.
