const { test, expect } = require('@playwright/test');

// ============================================================
// MODULE 01 EXERCISE — Getting Started with Playwright
// ============================================================
// Run this file with:
//   npx playwright test training/module-01-getting-started/exercises/exercise-01.spec.js
// ============================================================

// ------------------------------------------------------------
// TASK 1: Fix the broken test
// The test below has an intentional bug. The assertion is wrong.
// Fix it so that the test passes.
// ------------------------------------------------------------
test('Task 1: Fix the arithmetic test', async () => {
    const numOne = 10;
    const numTwo = 5;
    const total = numOne + numTwo;

    // BUG: This assertion is wrong. Fix the expected value.
    expect(total).toBe(99);
});


// ------------------------------------------------------------
// TASK 2: Write a test from scratch
// Write a test that:
//   - Defines a string variable called 'greeting' with the value 'Hello World'
//   - Asserts that greeting equals 'Hello World'
//   - Asserts that greeting contains the word 'World'
//     Hint: use .toContain() for the second assertion
// ------------------------------------------------------------
test('Task 2: String assertions', async () => {
    // Write your code here

});


// ------------------------------------------------------------
// TASK 3: Use soft assertions
// Write a test that checks MULTIPLE values in a single test.
// Use expect.soft() so that all assertions run even if one fails.
//
// The test should:
//   - Define an object: const user = { name: 'Zoro', job: 'Swordsman', age: 21 }
//   - Soft assert that user.name equals 'Zoro'
//   - Soft assert that user.job equals 'Chef'   <-- this one is wrong on purpose
//   - Soft assert that user.age equals 21
//
// Expected: test should FAIL but report 3 assertions (2 pass, 1 fail)
// ------------------------------------------------------------
test('Task 3: Multiple soft assertions', async () => {
    // Write your code here

});


// ------------------------------------------------------------
// TASK 4: Group tests with describe and add tags
// Move the two tests below into a test.describe block called
// 'Calculator Tests'. Add the tag @Positive to the passing test
// and @Negative to the failing test.
// ------------------------------------------------------------

// Move these into a test.describe block:
test('Task 4a: multiplication passes', async () => {
    expect(4 * 5).toBe(20);
});

test('Task 4b: division fails intentionally', async () => {
    expect(10 / 2).toBe(99); // intentionally wrong
});


// ------------------------------------------------------------
// TASK 5: Use beforeEach
// Create a test.describe block called 'Counter Tests'.
// Inside it:
//   - Declare a variable: let counter;
//   - Use beforeEach to reset counter to 0 before each test
//   - Write a test that increments counter by 1 and asserts it equals 1
//   - Write another test that increments counter by 5 and asserts it equals 5
// ------------------------------------------------------------

// Write your test.describe block here
