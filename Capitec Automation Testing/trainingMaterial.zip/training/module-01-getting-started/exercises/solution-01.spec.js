const { test, expect } = require('@playwright/test');

// ============================================================
// MODULE 01 SOLUTION — Getting Started with Playwright
// ============================================================

// TASK 1: Fix the broken test
test('Task 1: Fix the arithmetic test', async () => {
    const numOne = 10;
    const numTwo = 5;
    const total = numOne + numTwo;

    expect(total).toBe(15); // Fixed: 10 + 5 = 15
});


// TASK 2: Write a test from scratch
test('Task 2: String assertions', async () => {
    const greeting = 'Hello World';

    expect(greeting).toBe('Hello World');
    expect(greeting).toContain('World');
});


// TASK 3: Use soft assertions
test('Task 3: Multiple soft assertions', async () => {
    const user = { name: 'Zoro', job: 'Swordsman', age: 21 };

    expect.soft(user.name).toBe('Zoro');        // PASSES
    expect.soft(user.job).toBe('Chef');          // FAILS (job is 'Swordsman')
    expect.soft(user.age).toBe(21);              // PASSES
    // All three assertions run because we used expect.soft
});


// TASK 4: Group tests with describe and add tags
test.describe('Calculator Tests', () => {
    test('Task 4a: multiplication passes', { tag: ['@Positive'] }, async () => {
        expect(4 * 5).toBe(20);
    });

    test('Task 4b: division fails intentionally', { tag: ['@Negative'] }, async () => {
        expect(10 / 2).toBe(99); // intentionally wrong
    });
});


// TASK 5: Use beforeEach
test.describe('Counter Tests', () => {
    let counter;

    test.beforeEach(async () => {
        counter = 0; // Reset before each test
    });

    test('increments by 1', async () => {
        counter += 1;
        expect(counter).toBe(1);
    });

    test('increments by 5', async () => {
        counter += 5;
        expect(counter).toBe(5);
    });
});
