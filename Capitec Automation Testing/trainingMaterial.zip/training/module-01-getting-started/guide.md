# Module 01 — Getting Started with Playwright

## What is Playwright?

Playwright is a Node.js testing framework that lets you automate browsers and APIs. In this framework we use it to test web UIs, REST APIs, and databases — all from the same codebase.

Official docs: https://playwright.dev/docs/intro

---

## 1. Your First Test

Every test file in this framework follows the same basic pattern:

```javascript
const { test, expect } = require('@playwright/test');

test('My first test', async () => {
    // Your test logic here
    const result = 2 + 2;
    expect(result).toBe(4);
});
```

**Breaking it down:**
- `test(name, fn)` — defines a single test case
- `async` — tests are asynchronous (you'll use `await` inside them)
- `expect(value).toBe(expected)` — asserts that a value equals what you expect

**See it in the framework:** `tests/simple-test.spec.js`

---

## 2. Grouping Tests with `test.describe`

Use `test.describe` to group related tests together:

```javascript
const { test, expect } = require('@playwright/test');

test.describe('Arithmetic Tests', () => {
    test('adds two numbers', async () => {
        expect(2 + 2).toBe(4);
    });

    test('subtracts two numbers', async () => {
        expect(10 - 3).toBe(7);
    });
});
```

This groups tests in the report and makes it easier to filter and organise them.

---

## 3. Soft vs Hard Assertions

There are two types of assertions in Playwright:

### Hard Assertion (`expect`)
Stops the test immediately if the assertion fails:
```javascript
expect(result).toBe(8);  // If this fails, the test stops here
expect(name).toBe('Luffy');  // This line never runs if the above failed
```

### Soft Assertion (`expect.soft`)
Records the failure but continues running the test:
```javascript
expect.soft(result).toBe(8);    // Records failure if wrong
expect.soft(name).toBe('Luffy'); // Still runs even if the above failed
```

Use `expect.soft` when you want to check multiple things in a single test and see all failures at once (rather than stopping at the first one).

**See it in the framework:** `tests/simple-test.spec.js` uses `expect.soft` to test two assertions in one test.

---

## 4. Test Hooks

Hooks run code before or after your tests:

```javascript
test.describe('My Test Suite', () => {
    let sharedData;

    test.beforeAll(async () => {
        // Runs once before all tests in this describe block
        sharedData = { user: 'Luffy' };
    });

    test.beforeEach(async () => {
        // Runs before each individual test
        console.log('Starting a new test...');
    });

    test.afterEach(async () => {
        // Runs after each individual test
        console.log('Test finished.');
    });

    test.afterAll(async () => {
        // Runs once after all tests in this describe block
        console.log('All tests done.');
    });

    test('my test', async () => {
        expect(sharedData.user).toBe('Luffy');
    });
});
```

---

## 5. Test Tags

You can tag tests for filtering and reporting:

```javascript
test('My positive test', { tag: ['@Positive'] }, async () => {
    expect(1 + 1).toBe(2);
});

test('My negative test', { tag: ['@Negative'] }, async () => {
    expect(1 + 1).toBe(3); // intentionally wrong
});
```

The framework uses `@Positive` and `@Negative` tags. These are colour-coded in the Monocart report (green and red).

---

## 6. Running Tests

From the root of the framework:

```bash
# Run all tests
npx playwright test

# Run a specific file
npx playwright test tests/simple-test.spec.js

# Run in headed mode (see the browser)
npx playwright test --headed

# Run a specific test by name
npx playwright test --grep "My first test"

# Run with a specific browser
npx playwright test --browser=chromium
```

---

## 7. Test Metadata (JSDoc comments)

The framework uses JSDoc comments above tests to attach metadata for reporting:

```javascript
/**
 * @owner YourName
 * @jira PROJ-1234
 * @browserstack TC-001
 */
test('My test', async () => {
    // ...
});
```

This data shows up as custom columns in the HTML report.

---

## Summary

| Concept | Code |
|---------|------|
| Define a test | `test('name', async () => { ... })` |
| Group tests | `test.describe('group', () => { ... })` |
| Hard assertion | `expect(value).toBe(expected)` |
| Soft assertion | `expect.soft(value).toBe(expected)` |
| Before each test | `test.beforeEach(async () => { ... })` |
| Add tags | `test('name', { tag: ['@Positive'] }, async () => { ... })` |

---

## Exercise

Open `training/module-01-getting-started/exercises/exercise-01.spec.js` and complete the tasks described in the comments.

When done, compare your solution to `exercises/solution-01.spec.js`.
