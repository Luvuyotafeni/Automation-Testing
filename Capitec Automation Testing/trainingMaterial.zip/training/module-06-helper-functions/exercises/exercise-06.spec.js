const { test, expect } = require('@playwright/test');
const helpers = require('./my-helpers');

// ============================================================
// MODULE 06 EXERCISE — Helper Functions
// ============================================================
// Step 1: Open my-helpers.js and complete the three functions
// Step 2: Then come back here and complete these tests
//
// Run this file with:
//   npx playwright test training/module-06-helper-functions/exercises/exercise-06.spec.js
// ============================================================


// ------------------------------------------------------------
// TASK 1: Use the createUser helper
// Call helpers.createUser() to create a user named 'Franky' with job 'Shipwright'
// Assert that:
//   - The returned user.name equals 'Franky'
//   - The returned user.job equals 'Shipwright'
//   - The returned user.id is defined
// ------------------------------------------------------------
test('Task 1: Create user using helper', async ({ request }) => {
    // Write your code here

});


// ------------------------------------------------------------
// TASK 2: Use the getUserById helper
// Call helpers.getUserById(request, 1) to get user with ID 1
// Assert that:
//   - The returned body.data.id equals 1
//   - The returned body.data.email is defined
// ------------------------------------------------------------
test('Task 2: Get user by ID using helper', async ({ request }) => {
    // Write your code here

});


// ------------------------------------------------------------
// TASK 3: Use the getUsersOnPage helper
// Call helpers.getUsersOnPage(request, 1) to get users on page 1
// Assert that:
//   - The returned array has a length greater than 0
//   - The first user in the array has an 'email' field
// ------------------------------------------------------------
test('Task 3: Get users on page 1 using helper', async ({ request }) => {
    // Write your code here

});


// ------------------------------------------------------------
// TASK 4: Chain helpers together
// Use test.describe.serial to write two linked tests:
//   Test A: Create a user using helpers.createUser, save the result
//   Test B: Log the created user's name and ID (from saved result)
//           Assert that the saved user's name is defined
// ------------------------------------------------------------
test.describe.serial('Task 4: Chained helper calls', () => {
    let createdUser;

    test('4A: Create user with helper', async ({ request }) => {
        // Create a user named 'Brook' with job 'Musician'
        // Save to createdUser
        // Write your code here

    });

    test('4B: Use saved user data', async () => {
        // Log createdUser.name and createdUser.id
        // Assert createdUser.name is defined
        // Write your code here

    });
});
