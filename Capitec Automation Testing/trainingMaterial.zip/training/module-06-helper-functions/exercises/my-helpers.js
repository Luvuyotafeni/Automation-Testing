// ============================================================
// MY HELPERS — Module 06 Starter File
// ============================================================
// Complete the functions below.
// ============================================================

const { expect } = require('@playwright/test');

const BASE_URL = 'https://reqres.in/api';

module.exports = {

    // TASK 1: Complete this function
    // It should:
    //   - POST to BASE_URL + '/users' with { name, job }
    //   - Assert the response is OK
    //   - Return the parsed JSON body
    createUser: async function(request, name, job) {
        // Write your code here
    },


    // TASK 2: Complete this function
    // It should:
    //   - GET BASE_URL + '/users/' + userId
    //   - Assert the response is OK
    //   - Return the parsed JSON body
    getUserById: async function(request, userId) {
        // Write your code here
    },


    // TASK 3: Complete this function
    // It should:
    //   - GET BASE_URL + '/users?page=' + pageNumber
    //   - Assert the response is OK
    //   - Return body.data (the array of users)
    getUsersOnPage: async function(request, pageNumber) {
        // Write your code here
    }

};
