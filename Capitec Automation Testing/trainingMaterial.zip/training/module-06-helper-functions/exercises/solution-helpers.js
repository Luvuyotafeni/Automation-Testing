// ============================================================
// SOLUTION HELPERS — Module 06
// ============================================================

const { expect } = require('@playwright/test');

const BASE_URL = 'https://reqres.in/api';

module.exports = {

    createUser: async function(request, name, job) {
        const response = await request.post(`${BASE_URL}/users`, {
            data: { name, job }
        });
        expect(response.ok()).toBeTruthy();
        const body = await response.json();
        console.log(`Created user: ${body.name} (ID: ${body.id})`);
        return body;
    },

    getUserById: async function(request, userId) {
        const response = await request.get(`${BASE_URL}/users/${userId}`);
        expect(response.ok()).toBeTruthy();
        return await response.json();
    },

    getUsersOnPage: async function(request, pageNumber) {
        const response = await request.get(`${BASE_URL}/users?page=${pageNumber}`);
        expect(response.ok()).toBeTruthy();
        const body = await response.json();
        return body.data;
    }

};
