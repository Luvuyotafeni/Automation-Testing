const { test, expect } = require('@playwright/test');
const helpers = require('./solution-helpers');

// ============================================================
// MODULE 06 SOLUTION — Helper Functions
// ============================================================

// TASK 1
test('Task 1: Create user using helper', async ({ request }) => {
    const user = await helpers.createUser(request, 'Franky', 'Shipwright');

    expect(user.name).toBe('Franky');
    expect(user.job).toBe('Shipwright');
    expect(user.id).toBeDefined();
});


// TASK 2
test('Task 2: Get user by ID using helper', async ({ request }) => {
    const body = await helpers.getUserById(request, 1);

    expect(body.data.id).toBe(1);
    expect(body.data.email).toBeDefined();
});


// TASK 3
test('Task 3: Get users on page 1 using helper', async ({ request }) => {
    const users = await helpers.getUsersOnPage(request, 1);

    expect(users.length).toBeGreaterThan(0);
    expect(users[0].email).toBeDefined();
});


// TASK 4
test.describe.serial('Task 4: Chained helper calls', () => {
    let createdUser;

    test('4A: Create user with helper', async ({ request }) => {
        createdUser = await helpers.createUser(request, 'Brook', 'Musician');
        expect(createdUser).toBeDefined();
    });

    test('4B: Use saved user data', async () => {
        console.log('Created user name:', createdUser.name);
        console.log('Created user ID:', createdUser.id);
        expect(createdUser.name).toBeDefined();
    });
});
