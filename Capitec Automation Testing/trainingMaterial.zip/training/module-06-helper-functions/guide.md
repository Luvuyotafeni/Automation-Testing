# Module 06 — Helper Functions

## Why Helper Functions?

When multiple tests need the same logic (e.g., creating a user, logging in, making a deposit), repeating that code in every test leads to:
- Code duplication
- Harder maintenance (change one thing, update everywhere)
- Longer, harder-to-read tests

Helper functions solve this by extracting reusable logic into a separate file.

---

## 1. Creating a Helper File

Create a new file in the `functions/` folder (or alongside your tests):

```javascript
// functions/myHelpers.js

const { expect } = require('@playwright/test');

module.exports = {
    // Helper function to create a user via API
    createUser: async function(request, name, job) {
        const response = await request.post('https://reqres.in/api/users', {
            data: { name, job }
        });
        expect(response.ok()).toBeTruthy();
        const body = await response.json();
        console.log(`Created user: ${body.name} (ID: ${body.id})`);
        return body;
    },

    // Helper function to get a user by ID
    getUserById: async function(request, userId) {
        const response = await request.get(`https://reqres.in/api/users/${userId}`);
        expect(response.ok()).toBeTruthy();
        return await response.json();
    }
};
```

Key patterns:
- Use `module.exports = { ... }` to export multiple functions
- Functions are `async` to support `await`
- Accept `request`, `page`, or `driver` as parameters (don't import these)
- Return data that callers might need

**See it in the framework:** `functions/common.js` and `functions/apiRequest.js`

---

## 2. Using Helpers in Tests

Import with `require` and call the functions:

```javascript
const { test, expect } = require('@playwright/test');
const helpers = require('../../functions/myHelpers');

test('Create and verify a user', async ({ request }) => {
    // Use the helper instead of repeating the request logic
    const user = await helpers.createUser(request, 'Luffy', 'Pirate');

    expect(user.name).toBe('Luffy');
    expect(user.id).toBeDefined();
});
```

---

## 3. Passing Multiple Arguments

```javascript
module.exports = {
    // With multiple params
    createUserWithHeaders: async function(request, name, job, authToken) {
        const response = await request.post('https://reqres.in/api/users', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            },
            data: { name, job }
        });
        return await response.json();
    }
};
```

---

## 4. Using Objects for Options (cleaner for many params)

When a function has many parameters, use an options object:

```javascript
// Instead of: createUser(request, name, job, tag, owner, jira)
// Use:
module.exports = {
    createUser: async function(request, options) {
        const { name, job, tag = '@Positive', owner = 'Unknown' } = options;
        // tag and owner have defaults if not provided
        // ...
    }
};

// Calling it:
await helpers.createUser(request, {
    name: 'Zoro',
    job: 'Swordsman',
    owner: 'Jensen'
});
```

---

## 5. Real Framework Example

The framework's `common.js` exports functions used across all test files. Here's a simplified version of the pattern:

```javascript
// functions/common.js
const { expect } = require('@playwright/test');
const config = require('../config/environment_manager');

module.exports = {
    DepositIntoPrimary: async function(request, primaryAccount) {
        const response = await request.post(config.api.datagenDepositIntoPrimary, {
            headers: {
                'accept': 'application/json',
                'environment': 'bancs-' + process.env.ENV,
                'Content-Type': 'application/json'
            },
            data: {
                amount: 1000,
                primary_account: primaryAccount
            }
        });
        expect(response).toContain('O.K');
    }
};
```

Tests then call: `await common.DepositIntoPrimary(request, accountNumber);`

---

## 6. Organising Helpers

| File | What to put in it |
|------|-------------------|
| `functions/common.js` | Shared mobile app functions |
| `functions/apiRequest.js` | API request wrappers |
| `functions/testHelpers.js` | Your custom test helpers |

---

## Summary

1. Create a file in `functions/`
2. Export an object with `module.exports = { ... }`
3. Each helper is an `async function` that accepts what it needs
4. Import with `require()` and call with `await`

---

## Exercise

Open `training/module-06-helper-functions/exercises/exercise-06.spec.js` and complete the tasks.

A starter helper file `my-helpers.js` is provided in the same folder.

When done, compare with `exercises/solution-06.spec.js`.
