// ============================================================
// TRAINING CONFIG — Module 05
// ============================================================
// This is a simplified version of the framework's
// config/environment_manager.js pattern.
//
// TASK: Fill in the missing values for each environment.
// ============================================================

const trainingConfig = {
    api: {
        baseUrl: '',
        usersEndpoint: ''
    },
    ui: {
        url: ''
    },
    label: ''
};

switch (process.env.ENV) {
    case 'dev':
        // TODO: Set dev values
        // api.baseUrl = 'https://reqres.in/api'
        // api.usersEndpoint = '/users'
        // ui.url = 'https://playwright.dev'
        // label = 'Development'
        break;

    case 'int':
        // TODO: Set int values
        // Use the same reqres.in API but set label = 'Integration'
        break;

    case 'qa':
        // TODO: Set qa values
        // Use the same reqres.in API but set label = 'QA'
        break;

    default:
        // Fallback for when ENV is not set
        trainingConfig.api.baseUrl = 'https://reqres.in/api';
        trainingConfig.api.usersEndpoint = '/users';
        trainingConfig.ui.url = 'https://playwright.dev';
        trainingConfig.label = 'Default (no ENV set)';
        break;
}

module.exports = trainingConfig;
