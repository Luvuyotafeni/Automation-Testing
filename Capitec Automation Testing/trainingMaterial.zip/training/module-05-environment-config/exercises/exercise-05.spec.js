const { test, expect } = require('@playwright/test');
require('dotenv').config();

// ============================================================
// MODULE 05 EXERCISE — Environment Configuration
// ============================================================
// Run with different environments:
//   npx playwright test training/module-05-environment-config/exercises/exercise-05.spec.js
//   ENV=dev npx playwright test training/module-05-environment-config/exercises/exercise-05.spec.js
//   ENV=int npx playwright test training/module-05-environment-config/exercises/exercise-05.spec.js
// ============================================================


// ------------------------------------------------------------
// TASK 1: Read from process.env
// - Log the current value of process.env.ENV
// - Assert that process.env.ENV is either undefined, 'dev', 'int', or 'qa'
//   Hint: use expect(['dev','int','qa', undefined]).toContain(process.env.ENV)
// ------------------------------------------------------------
test('Task 1: Read process.env.ENV', async () => {
    const currentEnv = process.env.ENV;
    console.log('Current ENV:', currentEnv);

    // Write your assertion here

});


// ------------------------------------------------------------
// TASK 2: Complete the training-config.js file, then use it here
// - Open training-config.js in this folder and fill in the missing
//   values for each environment case
// - Then import the config and log config.label
// - Assert that config.api.baseUrl is defined (not empty string)
// ------------------------------------------------------------
// const trainingConfig = require('./training-config');

test('Task 2: Use the training config', async () => {
    // Uncomment the require above first, then:
    // - Log trainingConfig.label
    // - Assert trainingConfig.api.baseUrl is not empty
    // Write your code here

});


// ------------------------------------------------------------
// TASK 3: Use the config to make an API call
// - Import trainingConfig (uncomment the require above)
// - Use trainingConfig.api.baseUrl + trainingConfig.api.usersEndpoint
//   to build the URL for a GET request
// - Assert the response is OK
// - Log which environment/label was used
// ------------------------------------------------------------
test('Task 3: API test using config', async ({ request }) => {
    // Write your code here

});


// ------------------------------------------------------------
// TASK 4: Use the real framework config
// The framework already has a full environment_manager at:
//   config/environment_manager.js
//
// Import it and log what config.ui.url is for the current environment.
// (It may be empty if ENV is not set — that is fine for this exercise)
// ------------------------------------------------------------
const frameworkConfig = require('../../../config/environment_manager');

test('Task 4: Read from the real framework config', async () => {
    console.log('Framework UI URL:', frameworkConfig.ui.url);
    console.log('Framework DB host:', frameworkConfig.database.host);
    // No assertion needed - just observe the output
});
