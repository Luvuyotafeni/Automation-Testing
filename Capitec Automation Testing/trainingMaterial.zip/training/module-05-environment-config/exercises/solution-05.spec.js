const { test, expect } = require('@playwright/test');
require('dotenv').config();
const trainingConfig = require('./solution-config');
const frameworkConfig = require('../../../config/environment_manager');

// ============================================================
// MODULE 05 SOLUTION — Environment Configuration
// ============================================================

// TASK 1
test('Task 1: Read process.env.ENV', async () => {
    const currentEnv = process.env.ENV;
    console.log('Current ENV:', currentEnv);

    expect(['dev', 'int', 'qa', undefined]).toContain(currentEnv);
});


// TASK 2
test('Task 2: Use the training config', async () => {
    console.log('Config label:', trainingConfig.label);
    expect(trainingConfig.api.baseUrl).not.toBe('');
});


// TASK 3
test('Task 3: API test using config', async ({ request }) => {
    const url = trainingConfig.api.baseUrl + trainingConfig.api.usersEndpoint;
    console.log('Making request to:', url);
    console.log('Environment label:', trainingConfig.label);

    const response = await request.get(url);
    expect(response.ok()).toBeTruthy();
});


// TASK 4
test('Task 4: Read from the real framework config', async () => {
    console.log('Framework UI URL:', frameworkConfig.ui.url);
    console.log('Framework DB host:', frameworkConfig.database.host);
});
