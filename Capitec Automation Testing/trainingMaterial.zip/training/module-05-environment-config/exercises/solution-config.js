// ============================================================
// SOLUTION CONFIG — Module 05
// ============================================================

const trainingConfig = {
    api: {
        baseUrl: '',
        usersEndpoint: ''
    },
    ui: {
        url: ''
    },
    label: ''
};

switch (process.env.ENV) {
    case 'dev':
        trainingConfig.api.baseUrl = 'https://reqres.in/api';
        trainingConfig.api.usersEndpoint = '/users';
        trainingConfig.ui.url = 'https://playwright.dev';
        trainingConfig.label = 'Development';
        break;

    case 'int':
        trainingConfig.api.baseUrl = 'https://reqres.in/api';
        trainingConfig.api.usersEndpoint = '/users';
        trainingConfig.ui.url = 'https://playwright.dev';
        trainingConfig.label = 'Integration';
        break;

    case 'qa':
        trainingConfig.api.baseUrl = 'https://reqres.in/api';
        trainingConfig.api.usersEndpoint = '/users';
        trainingConfig.ui.url = 'https://playwright.dev';
        trainingConfig.label = 'QA';
        break;

    default:
        trainingConfig.api.baseUrl = 'https://reqres.in/api';
        trainingConfig.api.usersEndpoint = '/users';
        trainingConfig.ui.url = 'https://playwright.dev';
        trainingConfig.label = 'Default (no ENV set)';
        break;
}

module.exports = trainingConfig;
