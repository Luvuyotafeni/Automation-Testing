# Module 05 — Environment Configuration

## Why Environment Config?

Real applications run in multiple environments — `dev`, `int`, `qa`, and `prod`. Each has different URLs, credentials, and databases. Good test automation handles all environments without hardcoding values.

---

## 1. `.env` Files

A `.env` file stores environment variables as key-value pairs:

```
ENV=dev
DB_HOST=localhost
DB_PORT=5432
API_BASE_URL=https://api.dev.example.com
```

The framework uses the `dotenv` package to load these into `process.env`:

```javascript
require('dotenv').config();

console.log(process.env.ENV);           // 'dev'
console.log(process.env.API_BASE_URL);  // 'https://api.dev.example.com'
```

> **Security:** Never commit `.env` files with real credentials to git. Add `.env` to your `.gitignore`.

---

## 2. The Environment Manager Pattern

The framework uses a central config file to map environments to their URLs and settings.

**See it in the framework:** `config/environment_manager.js`

Here's the pattern simplified:

```javascript
// config/environment_manager.js

const config = {
    api: {
        baseUrl: ''
    },
    database: {
        host: '',
        port: 5432
    },
    ui: {
        url: ''
    }
};

switch (process.env.ENV) {
    case 'dev':
        config.api.baseUrl = 'https://api.dev.example.com';
        config.database.host = 'dev-db.example.com';
        config.ui.url = 'https://dev.example.com';
        break;

    case 'int':
        config.api.baseUrl = 'https://api.int.example.com';
        config.database.host = 'int-db.example.com';
        config.ui.url = 'https://int.example.com';
        break;

    case 'qa':
        config.api.baseUrl = 'https://api.qa.example.com';
        config.database.host = 'qa-db.example.com';
        config.ui.url = 'https://qa.example.com';
        break;
}

module.exports = config;
```

---

## 3. Using the Config in Tests

Import and use the config object in your tests:

```javascript
const { test, expect } = require('@playwright/test');
require('dotenv').config();
const config = require('../../config/environment_manager');

test('API test using environment config', async ({ request }) => {
    // Use config.api.baseUrl instead of hardcoding the URL
    const response = await request.get(config.api.baseUrl + '/users');
    expect(response.ok()).toBeTruthy();
});
```

---

## 4. Switching Environments

Set the `ENV` variable when running tests:

```bash
# Run against dev
ENV=dev npx playwright test

# Run against int
ENV=int npx playwright test

# Run against qa
ENV=qa npx playwright test
```

On Windows (PowerShell):
```powershell
$env:ENV="dev"; npx playwright test
```

---

## 5. Creating a Local `.env` File

Create a file called `.env` in the root of the framework:

```
ENV=dev
BROWSERSTACK_USERNAME=your_username
BROWSERSTACK_ACCESS_KEY=your_key
```

> **Note:** The framework's `.gitignore` should already exclude `.env` files. Check this before adding credentials.

---

## 6. Environment Variables vs Config File

| Approach | Best for |
|----------|----------|
| `.env` + `process.env` | Secrets, credentials, single values |
| `environment_manager.js` | Multiple URLs/settings per environment |

Use both together: `.env` stores the `ENV` variable and secrets, while `environment_manager.js` maps environments to their full configuration.

---

## Summary

```
.env file                    environment_manager.js
---------                    ----------------------
ENV=dev          ──────────► switch(process.env.ENV)
DB_PASSWORD=xxx              case 'dev': config.api.url = '...'
                             case 'int': config.api.url = '...'
                             case 'qa':  config.api.url = '...'
```

Your tests then `require('./config/environment_manager')` and use `config.api.url`, `config.database.host`, etc.

---

## Exercise

Open `training/module-05-environment-config/exercises/exercise-05.spec.js` and complete the tasks.

When done, compare with `exercises/solution-05.spec.js`.
