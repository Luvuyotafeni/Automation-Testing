# Module 04 — Data-Driven Testing

## What is Data-Driven Testing?

Data-driven testing means running the same test logic with different sets of input data. Instead of writing one test per scenario, you write one test template and loop over a dataset.

This is useful when:
- You need to test the same API endpoint with multiple users
- You have a spreadsheet of test cases
- You want to test boundary values (min, max, invalid inputs)

---

## 1. JSON Data-Driven Tests

Define your data as a JavaScript array of objects, then loop over it with `.forEach`:

```javascript
const { test, expect } = require('@playwright/test');

const testData = [
    { name: 'Luffy', job: 'Pirate' },
    { name: 'Zoro',  job: 'Swordsman' },
    { name: 'Sanji', job: 'Chef' }
];

test.describe('Data Driven Tests - JSON', () => {
    testData.forEach((data) => {
        test(`Create user: ${data.name}`, async ({ request }) => {
            const response = await request.post('https://reqres.in/api/users', {
                data: { name: data.name, job: data.job }
            });

            expect(response.ok()).toBeTruthy();

            const body = await response.json();
            expect(body.name).toBe(data.name);
            expect(body.job).toBe(data.job);
        });
    });
});
```

This generates **3 separate test cases** — one for each entry in `testData`.

**See it in the framework:** `tests/data-driven-tests.spec.js`

---

## 2. CSV Data-Driven Tests

For larger datasets, CSV files are easier to manage (especially for non-developers).

### Step 1: Create your CSV file
```csv
test_case;name;job;tags;owner
Test 1;Luffy;Pirate;Positive;Jensen
Test 2;Zoro;Swordsman;Positive;Jensen
Test 3;Sanji;Chef;Negative;Jensen
```

> The framework uses `;` as the delimiter (not `,`).

### Step 2: Parse the CSV in your test file
```javascript
const { test, expect } = require('@playwright/test');
const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse/sync');

const records = parse(
    fs.readFileSync(path.join(__dirname, 'test-data.csv')),
    {
        columns: true,        // use first row as column names
        delimiter: ';',       // match your CSV delimiter
        from: 1,              // start from row 1
        to: 500,              // read up to row 500
        skip_empty_lines: true
    }
);

test.describe('Data Driven Tests - CSV', () => {
    for (const record of records) {
        test(`${record.test_case}: Create ${record.name}`, async ({ request }) => {
            console.log('Test case:', record.test_case);
            console.log('Name:', record.name);

            const response = await request.post('https://reqres.in/api/users', {
                data: { name: record.name, job: record.job }
            });

            expect(response.ok()).toBeTruthy();

            const body = await response.json();
            expect(body.name).toBe(record.name);
        });
    }
});
```

**See it in the framework:** `tests/data-driven-tests.spec.js`

---

## 3. Controlling Which Rows to Run

The `from` and `to` options let you run a subset of your CSV data — useful during development:

```javascript
const records = parse(csvContent, {
    columns: true,
    delimiter: ';',
    from: 1,    // start at row 1 (after the header)
    to: 5,      // only run the first 5 rows
    skip_empty_lines: true
});
```

---

## 4. Marking Tests as Expected to Fail

If a test case is known to fail (e.g., a known bug), use `test.fail()` inside the test:

```javascript
test(`${record.test_case}: Create user`, async ({ request }) => {
    if (record.test_case === 'Test 1') {
        test.fail(); // Mark this test as expected to fail
    }
    // ...rest of test
});
```

**See it in the framework:** `tests/data-driven-tests.spec.js` lines 65–68.

---

## 5. Adding Metadata to Data-Driven Tests

You can attach metadata (owner, JIRA, etc.) to each generated test from your data:

```javascript
const { setMetadata } = require('monocart-reporter');

testData.forEach((data) => {
    test(`${data.testnum}: Create user`, { tag: data.tag }, async ({ request }) => {
        setMetadata({ owner: data.owner, browserstack: data.browserstack }, test.info());
        // ...
    });
});
```

**See it in the framework:** `tests/data-driven-tests.spec.js` — the JSON tests section.

---

## Summary

| Approach | When to use |
|----------|-------------|
| JSON array + `forEach` | Small datasets, defined in code |
| CSV file + `csv-parse` | Large datasets, managed in spreadsheets |
| `from` / `to` options | Run a subset during development |
| `test.fail()` | Mark known-failing cases explicitly |

---

## Exercise

Open `training/module-04-data-driven-testing/exercises/exercise-04.spec.js` and complete the tasks.

Sample data files are provided in the `exercises/` folder.

When done, compare with `exercises/solution-04.spec.js`.
