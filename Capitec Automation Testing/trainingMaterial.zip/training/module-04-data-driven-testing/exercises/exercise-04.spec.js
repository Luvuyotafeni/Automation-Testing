const { test, expect } = require('@playwright/test');
const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse/sync');

// ============================================================
// MODULE 04 EXERCISE — Data-Driven Testing
// ============================================================
// Run this file with:
//   npx playwright test training/module-04-data-driven-testing/exercises/exercise-04.spec.js
// ============================================================


// ------------------------------------------------------------
// TASK 1: JSON data-driven test
// Use the testData array below to generate one test per entry.
// Each test should:
//   - POST to https://jsonplaceholder.typicode.com/api/users with { name, job }
//   - Assert the response is OK
//   - Assert body.name equals data.name
//   - Assert body.job equals data.job
//
// The test name should include the character name:
//   e.g. `Create character: Luffy`
// ------------------------------------------------------------
const crewMembers = [
    { name: 'Luffy',  job: 'Captain' },
    { name: 'Zoro',   job: 'Swordsman' },
    { name: 'Nami',   job: 'Navigator' },
    { name: 'Chopper', job: 'Doctor' }
];

test.describe('Task 1: JSON data-driven tests', () => {
    // Write your forEach loop here

});


// ------------------------------------------------------------
// TASK 2: CSV data-driven test
// Parse the file 'characters.csv' (in this same folder) and
// generate one test per row.
// Each test should:
//   - Log the test_case, name, and job fields
//   - POST to https://jsonplaceholder.typicode.com/api/users with { name, job }
//   - Assert the response is OK (skip assertion if name is empty)
//
// For Test 5 (empty name), use test.fail() to mark it as expected to fail.
//
// Hint: path.join(__dirname, 'characters.csv') gives you the file path
// ------------------------------------------------------------

// Parse the CSV here (outside the describe block)
// const records = parse(...)

test.describe('Task 2: CSV data-driven tests', () => {
    // Write your for...of loop here

});


// ------------------------------------------------------------
// TASK 3: Limit CSV rows
// Copy your CSV parsing from Task 2 but only parse rows 1 to 3.
// Generate tests only for those rows and log a message showing
// which rows are being processed.
// ------------------------------------------------------------
test.describe('Task 3: CSV with row limits (rows 1-3 only)', () => {
    // Write your code here

});
