const { test, expect } = require('@playwright/test');
const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse/sync');

// ============================================================
// MODULE 04 SOLUTION — Data-Driven Testing
// ============================================================

// TASK 1
const crewMembers = [
    { name: 'Luffy',   job: 'Captain' },
    { name: 'Zoro',    job: 'Swordsman' },
    { name: 'Nami',    job: 'Navigator' },
    { name: 'Chopper', job: 'Doctor' }
];

test.describe('Task 1: JSON data-driven tests', () => {
    crewMembers.forEach((data) => {
        test(`Create character: ${data.name}`, async ({ request }) => {
            const response = await request.post('https://jsonplaceholder.typicode.com/api/users', {
                data: { name: data.name, job: data.job }
            });

            expect(response.ok()).toBeTruthy();

            const body = await response.json();
            expect(body.name).toBe(data.name);
            expect(body.job).toBe(data.job);
        });
    });
});


// TASK 2
const allRecords = parse(
    fs.readFileSync(path.join(__dirname, 'characters.csv')),
    {
        columns: true,
        delimiter: ';',
        from: 1,
        to: 500,
        skip_empty_lines: true
    }
);

test.describe('Task 2: CSV data-driven tests', () => {
    for (const record of allRecords) {
        test(`${record.test_case}: ${record.name || 'empty name'}`, async ({ request }) => {
            console.log('test_case:', record.test_case);
            console.log('name:', record.name);
            console.log('job:', record.job);

            // Mark Test 5 (empty name) as expected to fail
            if (!record.name) {
                test.fail();
            }

            const response = await request.post('https://jsonplaceholder.typicode.com/api/users', {
                data: { name: record.name, job: record.job }
            });

            expect(response.ok()).toBeTruthy();
        });
    }
});


// TASK 3
const limitedRecords = parse(
    fs.readFileSync(path.join(__dirname, 'characters.csv')),
    {
        columns: true,
        delimiter: ';',
        from: 1,
        to: 3,
        skip_empty_lines: true
    }
);

test.describe('Task 3: CSV with row limits (rows 1-3 only)', () => {
    for (const record of limitedRecords) {
        test(`${record.test_case}: ${record.name}`, async ({ request }) => {
            console.log(`Processing row: ${record.test_case}`);

            const response = await request.post('https://jsonplaceholder.typicode.com/api/users', {
                data: { name: record.name, job: record.job }
            });

            expect(response.ok()).toBeTruthy();

            const body = await response.json();
            expect(body.name).toBe(record.name);
        });
    }
});
