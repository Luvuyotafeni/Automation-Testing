// ============================================================
// PDF Generator — Automation Training Document
// ============================================================
// Usage: node training/generate-pdf.js
// Output: training/Automation-Training-Guide.pdf
// ============================================================

const { chromium } = require('@playwright/test');
const fs = require('fs');
const path = require('path');

const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Automation Testing Training Guide</title>
<style>
  /* ── Reset & base ── */
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 11pt;
    line-height: 1.65;
    color: #1a1a2e;
    background: #fff;
  }

  /* ── Page breaks ── */
  .page-break { page-break-after: always; break-after: page; }
  .no-break   { page-break-inside: avoid; break-inside: avoid; }

  /* ── Cover page ── */
  .cover {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    background: linear-gradient(135deg, #0f3460 0%, #16213e 60%, #1a1a2e 100%);
    color: #fff;
    text-align: center;
    padding: 60px 40px;
  }
  .cover-badge {
    background: rgba(255,255,255,0.12);
    border: 1px solid rgba(255,255,255,0.25);
    border-radius: 30px;
    padding: 6px 20px;
    font-size: 9pt;
    letter-spacing: 2px;
    text-transform: uppercase;
    margin-bottom: 32px;
    color: #e94560;
  }
  .cover h1 {
    font-size: 36pt;
    font-weight: 800;
    letter-spacing: -1px;
    line-height: 1.15;
    margin-bottom: 12px;
  }
  .cover h1 span { color: #e94560; }
  .cover .subtitle {
    font-size: 14pt;
    color: rgba(255,255,255,0.75);
    margin-bottom: 48px;
    font-weight: 300;
  }
  .cover-divider {
    width: 60px; height: 3px;
    background: #e94560;
    margin: 0 auto 40px;
    border-radius: 2px;
  }
  .cover-meta {
    display: flex;
    gap: 40px;
    justify-content: center;
    flex-wrap: wrap;
  }
  .cover-meta-item {
    text-align: center;
  }
  .cover-meta-item .number {
    font-size: 26pt;
    font-weight: 800;
    color: #e94560;
  }
  .cover-meta-item .label {
    font-size: 9pt;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: rgba(255,255,255,0.6);
  }
  .cover-footer {
    position: absolute;
    bottom: 32px;
    left: 0; right: 0;
    text-align: center;
    font-size: 8.5pt;
    color: rgba(255,255,255,0.4);
    letter-spacing: 0.5px;
  }

  /* ── Table of contents ── */
  .toc { padding: 56px 52px; }
  .toc h2 {
    font-size: 22pt;
    font-weight: 800;
    color: #0f3460;
    margin-bottom: 8px;
  }
  .toc-divider {
    width: 40px; height: 3px;
    background: #e94560;
    margin-bottom: 36px;
    border-radius: 2px;
  }
  .toc-item {
    display: flex;
    align-items: center;
    padding: 12px 0;
    border-bottom: 1px solid #f0f0f0;
  }
  .toc-num {
    width: 36px; height: 36px;
    background: #0f3460;
    color: #fff;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 9.5pt;
    font-weight: 700;
    flex-shrink: 0;
    margin-right: 16px;
  }
  .toc-title { font-size: 11.5pt; font-weight: 600; color: #1a1a2e; flex: 1; }
  .toc-badge {
    font-size: 8pt;
    padding: 3px 10px;
    border-radius: 12px;
    font-weight: 600;
    letter-spacing: 0.3px;
  }
  .badge-beginner     { background: #e8f5e9; color: #2e7d32; }
  .badge-intermediate { background: #fff3e0; color: #e65100; }

  /* ── Section / module layout ── */
  .module { padding: 52px 52px 40px; }
  .module-header {
    display: flex;
    align-items: center;
    gap: 18px;
    margin-bottom: 28px;
  }
  .module-num {
    width: 52px; height: 52px;
    background: linear-gradient(135deg, #0f3460, #e94560);
    color: #fff;
    border-radius: 14px;
    display: flex; align-items: center; justify-content: center;
    font-size: 16pt;
    font-weight: 800;
    flex-shrink: 0;
  }
  .module-title-block h2 {
    font-size: 20pt;
    font-weight: 800;
    color: #0f3460;
    line-height: 1.2;
  }
  .module-title-block .module-subtitle {
    font-size: 10pt;
    color: #888;
    margin-top: 2px;
  }
  .module-divider {
    height: 2px;
    background: linear-gradient(to right, #0f3460, transparent);
    margin-bottom: 28px;
    border-radius: 1px;
  }

  /* ── Content typography ── */
  h3 {
    font-size: 13pt;
    font-weight: 700;
    color: #0f3460;
    margin: 28px 0 10px;
    padding-bottom: 4px;
    border-bottom: 1.5px solid #e8ecf0;
  }
  h4 {
    font-size: 11pt;
    font-weight: 700;
    color: #1a1a2e;
    margin: 18px 0 6px;
  }
  p { margin-bottom: 10px; }
  ul, ol { margin: 8px 0 12px 22px; }
  li { margin-bottom: 4px; }
  strong { color: #0f3460; }

  /* ── Code blocks ── */
  pre {
    background: #1a1a2e;
    color: #e2e8f0;
    border-radius: 8px;
    padding: 16px 20px;
    font-family: 'Consolas', 'Courier New', monospace;
    font-size: 8.5pt;
    line-height: 1.55;
    overflow-x: auto;
    margin: 12px 0 16px;
    border-left: 3px solid #e94560;
    page-break-inside: avoid;
    break-inside: avoid;
  }
  code {
    background: #f0f4f8;
    color: #e94560;
    padding: 1px 5px;
    border-radius: 3px;
    font-family: 'Consolas', 'Courier New', monospace;
    font-size: 8.5pt;
  }
  pre code { background: transparent; color: inherit; padding: 0; font-size: inherit; }

  /* ── Callout boxes ── */
  .callout {
    border-radius: 8px;
    padding: 14px 18px;
    margin: 14px 0;
    border-left: 4px solid;
    page-break-inside: avoid;
    break-inside: avoid;
  }
  .callout-info    { background: #e8f4fd; border-color: #1565c0; color: #0d47a1; }
  .callout-tip     { background: #e8f5e9; border-color: #2e7d32; color: #1b5e20; }
  .callout-warning { background: #fff8e1; border-color: #f57f17; color: #e65100; }
  .callout-title   { font-weight: 700; margin-bottom: 4px; font-size: 9.5pt; text-transform: uppercase; letter-spacing: 0.5px; }

  /* ── Summary tables ── */
  table {
    width: 100%;
    border-collapse: collapse;
    margin: 14px 0 18px;
    font-size: 9.5pt;
    page-break-inside: avoid;
    break-inside: avoid;
  }
  th {
    background: #0f3460;
    color: #fff;
    padding: 8px 12px;
    text-align: left;
    font-weight: 600;
    font-size: 9pt;
  }
  td { padding: 7px 12px; border-bottom: 1px solid #eef0f4; }
  tr:nth-child(even) td { background: #f7f9fc; }

  /* ── Exercise boxes ── */
  .exercise-box {
    background: #f7f9fc;
    border: 1.5px solid #c5d5e8;
    border-radius: 10px;
    padding: 18px 20px;
    margin: 20px 0;
    page-break-inside: avoid;
    break-inside: avoid;
  }
  .exercise-box-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 10px;
  }
  .exercise-icon {
    width: 28px; height: 28px;
    background: #0f3460;
    color: #fff;
    border-radius: 6px;
    display: flex; align-items: center; justify-content: center;
    font-size: 13pt;
    flex-shrink: 0;
  }
  .exercise-box-header h4 {
    margin: 0;
    font-size: 11pt;
    color: #0f3460;
  }
  .exercise-task {
    margin: 8px 0;
    padding: 8px 12px;
    background: #fff;
    border-radius: 6px;
    border-left: 3px solid #0f3460;
    font-size: 9.5pt;
  }
  .exercise-task strong { color: #e94560; }

  /* ── Reference card at end ── */
  .ref-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
    margin: 20px 0;
  }
  .ref-card {
    background: #f7f9fc;
    border-radius: 8px;
    padding: 14px 16px;
    border-top: 3px solid #0f3460;
    page-break-inside: avoid;
    break-inside: avoid;
  }
  .ref-card h4 { font-size: 10pt; color: #0f3460; margin: 0 0 8px; }
  .ref-card pre { margin: 4px 0; font-size: 7.5pt; padding: 8px 10px; }
</style>
</head>
<body>

<!-- ══════════════════════════════════════════════════════════
     COVER PAGE
════════════════════════════════════════════════════════════ -->
<div class="cover">
  <div class="cover-badge">Quality Engineering</div>
  <h1>Automation Testing<br><span>Training Guide</span></h1>
  <div class="cover-divider"></div>
  <p class="subtitle">A beginner-to-intermediate guide to Playwright automation<br>based on the Loki Quality Engineering Framework</p>
  <div class="cover-meta">
    <div class="cover-meta-item">
      <div class="number">7</div>
      <div class="label">Modules</div>
    </div>
    <div class="cover-meta-item">
      <div class="number">30+</div>
      <div class="label">Exercises</div>
    </div>
    <div class="cover-meta-item">
      <div class="number">4</div>
      <div class="label">Topics</div>
    </div>
  </div>
  <div class="cover-footer">Loki Quality Engineering &nbsp;|&nbsp; Playwright Framework &nbsp;|&nbsp; 2026</div>
</div>

<!-- ══════════════════════════════════════════════════════════
     TABLE OF CONTENTS
════════════════════════════════════════════════════════════ -->
<div class="page-break"></div>
<div class="toc">
  <h2>Table of Contents</h2>
  <div class="toc-divider"></div>

  <div class="toc-item">
    <div class="toc-num">01</div>
    <div class="toc-title">Getting Started with Playwright</div>
    <span class="toc-badge badge-beginner">Beginner</span>
  </div>
  <div class="toc-item">
    <div class="toc-num">02</div>
    <div class="toc-title">API Testing</div>
    <span class="toc-badge badge-beginner">Beginner</span>
  </div>
  <div class="toc-item">
    <div class="toc-num">03</div>
    <div class="toc-title">UI Testing</div>
    <span class="toc-badge badge-beginner">Beginner</span>
  </div>
  <div class="toc-item">
    <div class="toc-num">04</div>
    <div class="toc-title">Data-Driven Testing</div>
    <span class="toc-badge badge-intermediate">Intermediate</span>
  </div>
  <div class="toc-item">
    <div class="toc-num">05</div>
    <div class="toc-title">Environment Configuration</div>
    <span class="toc-badge badge-intermediate">Intermediate</span>
  </div>
  <div class="toc-item">
    <div class="toc-num">06</div>
    <div class="toc-title">Helper Functions</div>
    <span class="toc-badge badge-intermediate">Intermediate</span>
  </div>
  <div class="toc-item">
    <div class="toc-num">07</div>
    <div class="toc-title">Reporting</div>
    <span class="toc-badge badge-intermediate">Intermediate</span>
  </div>

  <div style="margin-top:40px;">
    <h3 style="border:none;margin-top:0;">Prerequisites</h3>
    <ul>
      <li>Node.js 16 or higher installed (<code>node --version</code>)</li>
      <li>Framework cloned and dependencies installed (<code>npm install</code>)</li>
      <li>A code editor — VS Code is recommended</li>
    </ul>

    <div class="callout callout-tip" style="margin-top:16px;">
      <div class="callout-title">How to use this guide</div>
      Read each module guide, then open the matching exercise file and complete the tasks.
      Solutions are provided in the <code>exercises/</code> folder — try the exercise first before looking at the answer.
    </div>

    <h3>Running Exercises</h3>
    <pre># Run a specific module's exercises
npx playwright test training/module-01-getting-started/exercises/exercise-01.spec.js

# Run a specific module headed (see the browser)
npx playwright test training/module-03-ui-testing/exercises/exercise-03.spec.js --headed

# Run all training exercises at once
npx playwright test training/</pre>
  </div>
</div>

<!-- ══════════════════════════════════════════════════════════
     MODULE 01 — GETTING STARTED
════════════════════════════════════════════════════════════ -->
<div class="page-break"></div>
<div class="module">
  <div class="module-header">
    <div class="module-num">01</div>
    <div class="module-title-block">
      <h2>Getting Started with Playwright</h2>
      <div class="module-subtitle">Test structure &bull; Assertions &bull; Hooks &bull; Tags</div>
    </div>
  </div>
  <div class="module-divider"></div>

  <h3>What is Playwright?</h3>
  <p>Playwright is a Node.js testing framework that lets you automate browsers and APIs. In this framework we use it to test web UIs, REST APIs, and databases — all from the same codebase.</p>

  <h3>1. Your First Test</h3>
  <p>Every test file follows the same basic pattern:</p>
<pre>const { test, expect } = require('@playwright/test');

test('My first test', async () => {
    const result = 2 + 2;
    expect(result).toBe(4);
});</pre>

  <table>
    <tr><th>Part</th><th>What it does</th></tr>
    <tr><td><code>test(name, fn)</code></td><td>Defines a single test case</td></tr>
    <tr><td><code>async</code></td><td>Tests are asynchronous — you use <code>await</code> inside</td></tr>
    <tr><td><code>expect(value).toBe(x)</code></td><td>Asserts that a value equals what you expect</td></tr>
  </table>

  <div class="callout callout-info">
    <div class="callout-title">Framework reference</div>
    See <code>tests/simple-test.spec.js</code> for a real example of this pattern in the framework.
  </div>

  <h3>2. Grouping Tests with <code>test.describe</code></h3>
<pre>test.describe('Arithmetic Tests', () => {
    test('adds two numbers', async () => {
        expect(2 + 2).toBe(4);
    });

    test('subtracts two numbers', async () => {
        expect(10 - 3).toBe(7);
    });
});</pre>

  <h3>3. Soft vs Hard Assertions</h3>

  <h4>Hard Assertion (<code>expect</code>)</h4>
  <p>Stops the test immediately if the assertion fails:</p>
<pre>expect(result).toBe(8);      // If this fails, the test stops
expect(name).toBe('Luffy');  // This line never runs if above failed</pre>

  <h4>Soft Assertion (<code>expect.soft</code>)</h4>
  <p>Records the failure but continues running the test:</p>
<pre>expect.soft(result).toBe(8);     // Records failure if wrong
expect.soft(name).toBe('Luffy'); // Still runs even if above failed</pre>

  <div class="callout callout-tip">
    <div class="callout-title">When to use soft assertions</div>
    Use <code>expect.soft</code> when you want to check multiple things in a single test and see <em>all</em> failures at once, rather than stopping at the first one.
  </div>

  <h3>4. Test Hooks</h3>
<pre>test.describe('My Suite', () => {
    let sharedData;

    test.beforeAll(async () => { /* runs once before all tests */ });
    test.beforeEach(async () => { /* runs before each test */ });
    test.afterEach(async () => { /* runs after each test */ });
    test.afterAll(async () => { /* runs once after all tests */ });

    test('example', async () => {
        // your test logic
    });
});</pre>

  <h3>5. Test Tags</h3>
<pre>test('Positive test', { tag: ['@Positive'] }, async () => {
    expect(1 + 1).toBe(2);
});

test('Negative test', { tag: ['@Negative'] }, async () => {
    expect(1 + 1).toBe(3); // intentionally wrong
});</pre>
  <p>The framework colour-codes <code>@Positive</code> (green) and <code>@Negative</code> (red) in the HTML report.</p>

  <h3>6. Running Tests</h3>
<pre># Run all tests
npx playwright test

# Run a specific file
npx playwright test tests/simple-test.spec.js

# Run in headed mode (see the browser)
npx playwright test --headed

# Filter by test name
npx playwright test --grep "My first test"</pre>

  <h3>Summary</h3>
  <table>
    <tr><th>Concept</th><th>Code</th></tr>
    <tr><td>Define a test</td><td><code>test('name', async () => { ... })</code></td></tr>
    <tr><td>Group tests</td><td><code>test.describe('group', () => { ... })</code></td></tr>
    <tr><td>Hard assertion</td><td><code>expect(value).toBe(expected)</code></td></tr>
    <tr><td>Soft assertion</td><td><code>expect.soft(value).toBe(expected)</code></td></tr>
    <tr><td>Before each test</td><td><code>test.beforeEach(async () => { ... })</code></td></tr>
    <tr><td>Add tags</td><td><code>test('name', { tag: ['@Positive'] }, async () => { ... })</code></td></tr>
  </table>

  <div class="exercise-box">
    <div class="exercise-box-header">
      <div class="exercise-icon">&#9998;</div>
      <h4>Exercise 01 &mdash; <code>training/module-01-getting-started/exercises/exercise-01.spec.js</code></h4>
    </div>
    <div class="exercise-task"><strong>Task 1:</strong> Fix a broken test with the wrong expected value</div>
    <div class="exercise-task"><strong>Task 2:</strong> Write a test using string assertions (<code>toBe</code>, <code>toContain</code>)</div>
    <div class="exercise-task"><strong>Task 3:</strong> Use <code>expect.soft</code> to check multiple values in one test</div>
    <div class="exercise-task"><strong>Task 4:</strong> Group tests with <code>test.describe</code> and add <code>@Positive</code> / <code>@Negative</code> tags</div>
    <div class="exercise-task"><strong>Task 5:</strong> Use <code>beforeEach</code> to reset a counter before each test</div>
  </div>
</div>

<!-- ══════════════════════════════════════════════════════════
     MODULE 02 — API TESTING
════════════════════════════════════════════════════════════ -->
<div class="page-break"></div>
<div class="module">
  <div class="module-header">
    <div class="module-num">02</div>
    <div class="module-title-block">
      <h2>API Testing</h2>
      <div class="module-subtitle">GET &bull; POST &bull; PUT &bull; DELETE &bull; Headers &bull; Chaining</div>
    </div>
  </div>
  <div class="module-divider"></div>

  <h3>What is API Testing?</h3>
  <p>API testing means sending HTTP requests directly to a server (without a browser) and validating the responses. It's faster and more reliable than UI testing for checking business logic.</p>
  <p>In Playwright, API requests are made using the <code>request</code> fixture — no extra libraries needed.</p>

  <h3>1. The <code>request</code> Fixture</h3>
<pre>const { test, expect } = require('@playwright/test');

test('My API test', async ({ request }) => {
    // Use 'request' to make HTTP calls
});</pre>

  <h3>2. GET Requests</h3>
<pre>test('GET users', async ({ request }) => {
    const response = await request.get('https://reqres.in/api/users?page=2');

    expect(response.ok()).toBeTruthy();     // status is 2xx
    expect(response.status()).toBe(200);   // exact status code

    const body = await response.json();    // parse the JSON body
    expect(body.page).toBe(2);
    expect(body.data.length).toBeGreaterThan(0);
});</pre>

  <h3>3. POST Requests</h3>
<pre>test('POST create user', async ({ request }) => {
    const response = await request.post('https://reqres.in/api/users', {
        data: { name: 'Luffy', job: 'Pirate' }
    });

    expect(response.ok()).toBeTruthy();

    const body = await response.json();
    expect(body.name).toBe('Luffy');
    expect(body.id).toBeDefined();
});</pre>

  <h3>4. Sending Headers</h3>
<pre>const response = await request.post('https://reqres.in/api/users', {
    headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer my-token'
    },
    data: { name: 'Sanji', job: 'Chef' }
});</pre>

  <h3>5. Common API Assertions</h3>
<pre>const body = await response.json();

expect(response.ok()).toBeTruthy();            // 2xx status
expect(response.status()).toBe(200);           // exact status
expect(body.name).toBe('Luffy');              // exact value
expect(body.data).toHaveLength(6);            // array length
expect(body.data.length).toBeGreaterThan(0);  // at least one
expect(body.id).toBeDefined();                // field exists
expect(body.email).toContain('@');            // string contains</pre>

  <h3>6. Chaining API Calls (serial)</h3>
<pre>test.describe.serial('User flow', () => {
    let createdUserId;

    test('Create a user', async ({ request }) => {
        const response = await request.post('https://reqres.in/api/users', {
            data: { name: 'Luffy', job: 'Pirate' }
        });
        const body = await response.json();
        createdUserId = body.id;
    });

    test('Use the ID from the previous test', async ({ request }) => {
        console.log('Using ID:', createdUserId);
        expect(createdUserId).toBeDefined();
    });
});</pre>

  <div class="callout callout-warning">
    <div class="callout-title">Important</div>
    Use <code>test.describe.serial</code> (not the default parallel) when tests depend on each other's output.
  </div>

  <h3>Summary</h3>
  <table>
    <tr><th>Method</th><th>Playwright code</th></tr>
    <tr><td>GET</td><td><code>request.get(url)</code></td></tr>
    <tr><td>POST</td><td><code>request.post(url, { data: {...} })</code></td></tr>
    <tr><td>PUT</td><td><code>request.put(url, { data: {...} })</code></td></tr>
    <tr><td>DELETE</td><td><code>request.delete(url)</code></td></tr>
    <tr><td>Add headers</td><td><code>request.get(url, { headers: {...} })</code></td></tr>
    <tr><td>Parse body</td><td><code>await response.json()</code></td></tr>
    <tr><td>Check status</td><td><code>response.status()</code> or <code>response.ok()</code></td></tr>
  </table>

  <div class="exercise-box">
    <div class="exercise-box-header">
      <div class="exercise-icon">&#9998;</div>
      <h4>Exercise 02 &mdash; <code>training/module-02-api-testing/exercises/exercise-02.spec.js</code></h4>
    </div>
    <div class="exercise-task"><strong>Task 1:</strong> GET list of users and validate the response structure</div>
    <div class="exercise-task"><strong>Task 2:</strong> GET a single user by ID and validate their email</div>
    <div class="exercise-task"><strong>Task 3:</strong> POST to create a user and validate all response fields</div>
    <div class="exercise-task"><strong>Task 4:</strong> PUT to update a user and validate <code>updatedAt</code> is present</div>
    <div class="exercise-task"><strong>Task 5:</strong> Chain two tests with <code>describe.serial</code> — create then reference a user</div>
  </div>
</div>

<!-- ══════════════════════════════════════════════════════════
     MODULE 03 — UI TESTING
════════════════════════════════════════════════════════════ -->
<div class="page-break"></div>
<div class="module">
  <div class="module-header">
    <div class="module-num">03</div>
    <div class="module-title-block">
      <h2>UI Testing</h2>
      <div class="module-subtitle">Navigation &bull; Locators &bull; Assertions &bull; Screenshots</div>
    </div>
  </div>
  <div class="module-divider"></div>

  <h3>What is UI Testing?</h3>
  <p>UI testing automates a real browser — clicking buttons, filling forms, navigating pages — and verifying that what appears on screen is correct. Playwright controls Chromium, Firefox, and WebKit.</p>

  <h3>1. The <code>page</code> Fixture</h3>
<pre>test('My UI test', async ({ page }) => {
    // Use 'page' to control the browser
});</pre>

  <h3>2. Navigation</h3>
<pre>await page.goto('https://playwright.dev/');</pre>

  <h3>3. Finding Elements — Locators</h3>
  <p>Use these strategies in order of preference (most reliable first):</p>

  <h4>By Role (recommended)</h4>
<pre>await page.getByRole('button', { name: 'Submit' }).click();
await page.getByRole('link', { name: 'Get started' }).click();
await page.getByRole('heading', { name: 'Installation' });</pre>

  <h4>By Label (for form fields)</h4>
<pre>await page.getByLabel('Email').fill('user@example.com');</pre>

  <h4>By Text</h4>
<pre>await page.getByText('Welcome').click();</pre>

  <h4>By Placeholder</h4>
<pre>await page.getByPlaceholder('Enter your name').fill('Luffy');</pre>

  <h4>CSS Selector (fallback)</h4>
<pre>await page.locator('button.primary').click();
await page.locator('#username').fill('Luffy');</pre>

  <h3>4. Interacting with Elements</h3>
<pre>await page.getByRole('button', { name: 'Submit' }).click();    // click
await page.getByLabel('Username').fill('Luffy');               // type
await page.keyboard.press('Enter');                            // keypress
await page.getByLabel('Country').selectOption('South Africa'); // dropdown
await page.getByLabel('Remember me').check();                  // checkbox</pre>

  <h3>5. Assertions for UI</h3>
<pre>await expect(page.getByRole('heading', { name: 'Home' })).toBeVisible();
await expect(page.getByRole('button')).not.toBeVisible();
await expect(page.getByRole('paragraph')).toContainText('Welcome');
await expect(page).toHaveTitle('My App');
await expect(page).toHaveURL('https://example.com/dashboard');</pre>

  <h3>6. Taking Screenshots</h3>
<pre>test('UI test with screenshot', async ({ page }, testInfo) => {
    await page.goto('https://playwright.dev/');

    const screenshot = await page.screenshot({ fullPage: true });
    await testInfo.attach('screenshot', {
        body: screenshot,
        contentType: 'image/png'
    });
});</pre>

  <div class="callout callout-info">
    <div class="callout-title">Framework reference</div>
    This exact pattern is used in <code>tests/front-end-tests.spec.js</code>.
  </div>

  <h3>Summary</h3>
  <table>
    <tr><th>Action</th><th>Code</th></tr>
    <tr><td>Go to URL</td><td><code>await page.goto('https://...')</code></td></tr>
    <tr><td>Click</td><td><code>await page.getByRole('button', { name: 'x' }).click()</code></td></tr>
    <tr><td>Fill input</td><td><code>await page.getByLabel('x').fill('value')</code></td></tr>
    <tr><td>Assert visible</td><td><code>await expect(page.getByRole('heading')).toBeVisible()</code></td></tr>
    <tr><td>Assert text</td><td><code>await expect(element).toContainText('text')</code></td></tr>
    <tr><td>Take screenshot</td><td><code>await page.screenshot({ fullPage: true })</code></td></tr>
    <tr><td>Run headed</td><td><code>npx playwright test --headed</code></td></tr>
  </table>

  <div class="exercise-box">
    <div class="exercise-box-header">
      <div class="exercise-icon">&#9998;</div>
      <h4>Exercise 03 &mdash; <code>training/module-03-ui-testing/exercises/exercise-03.spec.js</code></h4>
    </div>
    <div class="exercise-task"><strong>Task 1:</strong> Navigate to playwright.dev and assert the page title</div>
    <div class="exercise-task"><strong>Task 2:</strong> Click "Get started" and verify the heading on the next page</div>
    <div class="exercise-task"><strong>Task 3:</strong> Take a full-page screenshot and attach it to the report</div>
    <div class="exercise-task"><strong>Task 4:</strong> Use <code>expect.soft</code> for multiple UI element checks</div>
    <div class="exercise-task"><strong>Task 5:</strong> Complete a multi-step navigation flow with screenshot</div>
  </div>
</div>

<!-- ══════════════════════════════════════════════════════════
     MODULE 04 — DATA-DRIVEN TESTING
════════════════════════════════════════════════════════════ -->
<div class="page-break"></div>
<div class="module">
  <div class="module-header">
    <div class="module-num">04</div>
    <div class="module-title-block">
      <h2>Data-Driven Testing</h2>
      <div class="module-subtitle">JSON arrays &bull; CSV files &bull; Row limits &bull; test.fail()</div>
    </div>
  </div>
  <div class="module-divider"></div>

  <h3>What is Data-Driven Testing?</h3>
  <p>Data-driven testing runs the same test logic with different sets of input data. Instead of writing one test per scenario, you write one test template and loop over a dataset.</p>

  <h3>1. JSON Data-Driven Tests</h3>
<pre>const testData = [
    { name: 'Luffy', job: 'Pirate' },
    { name: 'Zoro',  job: 'Swordsman' },
    { name: 'Sanji', job: 'Chef' }
];

test.describe('Data Driven Tests', () => {
    testData.forEach((data) => {
        test(\`Create user: \${data.name}\`, async ({ request }) => {
            const response = await request.post('https://reqres.in/api/users', {
                data: { name: data.name, job: data.job }
            });
            expect(response.ok()).toBeTruthy();
            const body = await response.json();
            expect(body.name).toBe(data.name);
        });
    });
});</pre>
  <p>This generates <strong>3 separate test cases</strong> — one per entry.</p>

  <h3>2. CSV Data-Driven Tests</h3>
  <h4>Step 1: Create your CSV file</h4>
<pre>test_case;name;job;tags;owner
Test 1;Luffy;Pirate;Positive;Jensen
Test 2;Zoro;Swordsman;Positive;Jensen</pre>

  <div class="callout callout-tip">
    <div class="callout-title">Tip</div>
    The framework uses <code>;</code> as the CSV delimiter, not <code>,</code>.
  </div>

  <h4>Step 2: Parse and loop</h4>
<pre>const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse/sync');

const records = parse(
    fs.readFileSync(path.join(__dirname, 'test-data.csv')),
    { columns: true, delimiter: ';', from: 1, to: 500, skip_empty_lines: true }
);

test.describe('CSV Tests', () => {
    for (const record of records) {
        test(\`\${record.test_case}: \${record.name}\`, async ({ request }) => {
            const response = await request.post('https://reqres.in/api/users', {
                data: { name: record.name, job: record.job }
            });
            expect(response.ok()).toBeTruthy();
        });
    }
});</pre>

  <h3>3. Controlling Rows with <code>from</code> / <code>to</code></h3>
<pre>const records = parse(csvContent, {
    columns: true,
    delimiter: ';',
    from: 1,   // start at row 1
    to: 5,     // only run first 5 rows
    skip_empty_lines: true
});</pre>

  <h3>4. Marking Known Failures</h3>
<pre>test(\`\${record.test_case}: Create user\`, async () => {
    if (record.test_case === 'Test 5') {
        test.fail(); // Mark as expected to fail
    }
    // ...
});</pre>

  <h3>Summary</h3>
  <table>
    <tr><th>Approach</th><th>When to use</th></tr>
    <tr><td>JSON array + <code>forEach</code></td><td>Small datasets defined in code</td></tr>
    <tr><td>CSV + <code>csv-parse</code></td><td>Large datasets managed in spreadsheets</td></tr>
    <tr><td><code>from</code> / <code>to</code> options</td><td>Run a subset during development</td></tr>
    <tr><td><code>test.fail()</code></td><td>Mark known-failing cases explicitly</td></tr>
  </table>

  <div class="exercise-box">
    <div class="exercise-box-header">
      <div class="exercise-icon">&#9998;</div>
      <h4>Exercise 04 &mdash; <code>training/module-04-data-driven-testing/exercises/exercise-04.spec.js</code></h4>
    </div>
    <div class="exercise-task"><strong>Task 1:</strong> Write JSON data-driven tests using a <code>forEach</code> loop over a character array</div>
    <div class="exercise-task"><strong>Task 2:</strong> Parse <code>characters.csv</code> and generate one test per row; mark the empty-name row with <code>test.fail()</code></div>
    <div class="exercise-task"><strong>Task 3:</strong> Repeat Task 2 but limit to rows 1–3 only</div>
  </div>
</div>

<!-- ══════════════════════════════════════════════════════════
     MODULE 05 — ENVIRONMENT CONFIG
════════════════════════════════════════════════════════════ -->
<div class="page-break"></div>
<div class="module">
  <div class="module-header">
    <div class="module-num">05</div>
    <div class="module-title-block">
      <h2>Environment Configuration</h2>
      <div class="module-subtitle">.env files &bull; environment_manager &bull; Switching environments</div>
    </div>
  </div>
  <div class="module-divider"></div>

  <h3>Why Environment Config?</h3>
  <p>Real applications run in multiple environments — <code>dev</code>, <code>int</code>, <code>qa</code>, and <code>prod</code>. Good test automation handles all environments without hardcoding values.</p>

  <h3>1. <code>.env</code> Files</h3>
<pre># .env
ENV=dev
DB_HOST=localhost
API_BASE_URL=https://api.dev.example.com</pre>

  <p>Load into <code>process.env</code> at the top of your test file:</p>
<pre>require('dotenv').config();
console.log(process.env.ENV);          // 'dev'
console.log(process.env.API_BASE_URL); // 'https://api.dev.example.com'</pre>

  <div class="callout callout-warning">
    <div class="callout-title">Security</div>
    Never commit <code>.env</code> files with real credentials to git. Add <code>.env</code> to your <code>.gitignore</code>.
  </div>

  <h3>2. The Environment Manager Pattern</h3>
  <p>The framework uses <code>config/environment_manager.js</code> to map environments to their full configuration:</p>
<pre>// config/environment_manager.js
const config = {
    api:      { baseUrl: '' },
    database: { host: '', port: 5432 },
    ui:       { url: '' }
};

switch (process.env.ENV) {
    case 'dev':
        config.api.baseUrl  = 'https://api.dev.example.com';
        config.ui.url       = 'https://dev.example.com';
        break;
    case 'int':
        config.api.baseUrl  = 'https://api.int.example.com';
        config.ui.url       = 'https://int.example.com';
        break;
    case 'qa':
        config.api.baseUrl  = 'https://api.qa.example.com';
        config.ui.url       = 'https://qa.example.com';
        break;
}
module.exports = config;</pre>

  <h3>3. Using the Config in Tests</h3>
<pre>const config = require('../../config/environment_manager');

test('API test using config', async ({ request }) => {
    const response = await request.get(config.api.baseUrl + '/users');
    expect(response.ok()).toBeTruthy();
});</pre>

  <h3>4. Switching Environments</h3>
<pre># macOS / Linux
ENV=dev  npx playwright test
ENV=int  npx playwright test
ENV=qa   npx playwright test

# Windows PowerShell
$env:ENV="dev"; npx playwright test</pre>

  <h3>Summary</h3>
  <table>
    <tr><th>Approach</th><th>Best for</th></tr>
    <tr><td><code>.env</code> + <code>process.env</code></td><td>Secrets, credentials, single values</td></tr>
    <tr><td><code>environment_manager.js</code></td><td>Multiple URLs and settings per environment</td></tr>
  </table>

  <div class="exercise-box">
    <div class="exercise-box-header">
      <div class="exercise-icon">&#9998;</div>
      <h4>Exercise 05 &mdash; <code>training/module-05-environment-config/exercises/exercise-05.spec.js</code></h4>
    </div>
    <div class="exercise-task"><strong>Task 1:</strong> Read and log <code>process.env.ENV</code>; assert it is a valid value</div>
    <div class="exercise-task"><strong>Task 2:</strong> Complete <code>training-config.js</code>, then import and validate it</div>
    <div class="exercise-task"><strong>Task 3:</strong> Use the config to build a URL and make an API call</div>
    <div class="exercise-task"><strong>Task 4:</strong> Import the real framework config and observe the current environment values</div>
  </div>
</div>

<!-- ══════════════════════════════════════════════════════════
     MODULE 06 — HELPER FUNCTIONS
════════════════════════════════════════════════════════════ -->
<div class="page-break"></div>
<div class="module">
  <div class="module-header">
    <div class="module-num">06</div>
    <div class="module-title-block">
      <h2>Helper Functions</h2>
      <div class="module-subtitle">module.exports &bull; Reusable functions &bull; Import patterns</div>
    </div>
  </div>
  <div class="module-divider"></div>

  <h3>Why Helper Functions?</h3>
  <p>When multiple tests need the same logic (e.g. creating a user, logging in), repeating that code in every test leads to duplication, harder maintenance, and longer tests. Helper functions solve this by extracting reusable logic into a separate file.</p>

  <h3>1. Creating a Helper File</h3>
<pre>// functions/myHelpers.js
const { expect } = require('@playwright/test');

module.exports = {

    createUser: async function(request, name, job) {
        const response = await request.post('https://reqres.in/api/users', {
            data: { name, job }
        });
        expect(response.ok()).toBeTruthy();
        const body = await response.json();
        console.log(\`Created user: \${body.name} (ID: \${body.id})\`);
        return body;
    },

    getUserById: async function(request, userId) {
        const response = await request.get(\`https://reqres.in/api/users/\${userId}\`);
        expect(response.ok()).toBeTruthy();
        return await response.json();
    }

};</pre>

  <h4>Key patterns:</h4>
  <ul>
    <li>Use <code>module.exports = { ... }</code> to export multiple functions</li>
    <li>Functions are <code>async</code> to support <code>await</code></li>
    <li>Accept <code>request</code> or <code>page</code> as parameters — don't import the fixture</li>
    <li>Return data so callers can use the response</li>
  </ul>

  <div class="callout callout-info">
    <div class="callout-title">Framework reference</div>
    See <code>functions/common.js</code> and <code>functions/apiRequest.js</code> for real production examples.
  </div>

  <h3>2. Using Helpers in Tests</h3>
<pre>const helpers = require('../../functions/myHelpers');

test('Create and verify a user', async ({ request }) => {
    const user = await helpers.createUser(request, 'Luffy', 'Pirate');
    expect(user.name).toBe('Luffy');
    expect(user.id).toBeDefined();
});</pre>

  <h3>3. Options Object Pattern (for many params)</h3>
<pre>// Instead of: createUser(request, name, job, tag, owner, jira)
createUser: async function(request, options) {
    const { name, job, owner = 'Unknown' } = options;
    // owner has a default value if not provided
}

// Call it like this:
await helpers.createUser(request, { name: 'Zoro', job: 'Swordsman', owner: 'Jensen' });</pre>

  <h3>4. Organising Helpers</h3>
  <table>
    <tr><th>File</th><th>What to put in it</th></tr>
    <tr><td><code>functions/common.js</code></td><td>Shared mobile app functions (login, navigation)</td></tr>
    <tr><td><code>functions/apiRequest.js</code></td><td>API request wrappers</td></tr>
    <tr><td><code>functions/myHelpers.js</code></td><td>Your custom test helpers</td></tr>
  </table>

  <div class="exercise-box">
    <div class="exercise-box-header">
      <div class="exercise-icon">&#9998;</div>
      <h4>Exercise 06 &mdash; <code>training/module-06-helper-functions/exercises/exercise-06.spec.js</code></h4>
    </div>
    <div class="exercise-task"><strong>Task 1:</strong> Complete <code>createUser</code> in <code>my-helpers.js</code>, then use it in a test</div>
    <div class="exercise-task"><strong>Task 2:</strong> Complete <code>getUserById</code> and use it to fetch user ID 1</div>
    <div class="exercise-task"><strong>Task 3:</strong> Complete <code>getUsersOnPage</code> and assert the returned array is not empty</div>
    <div class="exercise-task"><strong>Task 4:</strong> Chain two serial tests — create a user with a helper, then reference the saved result</div>
  </div>
</div>

<!-- ══════════════════════════════════════════════════════════
     MODULE 07 — REPORTING
════════════════════════════════════════════════════════════ -->
<div class="page-break"></div>
<div class="module">
  <div class="module-header">
    <div class="module-num">07</div>
    <div class="module-title-block">
      <h2>Reporting</h2>
      <div class="module-subtitle">Monocart &bull; Tags &bull; Metadata &bull; test.step() &bull; Screenshots</div>
    </div>
  </div>
  <div class="module-divider"></div>

  <h3>Overview</h3>
  <p>The framework uses <strong>Monocart Reporter</strong> to generate rich HTML test reports. Good reporting makes it easy to see which tests passed or failed, who owns each test, and link tests to JIRA tickets.</p>

  <h3>Generating the Report</h3>
<pre># Run tests — report is generated automatically
npx playwright test

# Open the report
open test-results/report.html</pre>

  <h3>1. Test Tags</h3>
<pre>test('Happy path test', { tag: ['@Positive'] }, async ({ request }) => { ... });
test('Error case test',  { tag: ['@Negative'] }, async ({ request }) => { ... });</pre>
  <p>The report colour-codes <code>@Positive</code> (green) and <code>@Negative</code> (red).</p>

  <h3>2. Metadata — JSDoc Approach</h3>
<pre>/**
 * @owner YourName
 * @jira PROJ-1234
 * @browserstack TC-001
 */
test('My test', async () => { ... });</pre>

  <h3>3. Metadata — Dynamic Approach (<code>setMetadata</code>)</h3>
  <p>Use this inside data-driven loops where metadata changes per row:</p>
<pre>const { setMetadata } = require('monocart-reporter');

testData.forEach((data) => {
    test(\`Test: \${data.name}\`, async ({}, testInfo) => {
        setMetadata({ owner: data.owner, jira: data.jira }, test.info());
        // ...
    });
});</pre>

  <h3>4. <code>test.step()</code> — Granular Reporting</h3>
  <p>Break your test into named steps that appear as collapsible sections in the report:</p>
<pre>test('User workflow', async ({ request }) => {
    let user;

    await test.step('POST: Create user', async () => {
        const response = await request.post('https://reqres.in/api/users', {
            data: { name: 'Luffy', job: 'Pirate' }
        });
        user = await response.json();
        expect(user.name).toBe('Luffy');
    });

    await test.step('Validate ID is present', async () => {
        expect(user.id).toBeDefined();
        console.log('Created ID:', user.id);
    });
});</pre>

  <h3>5. A Fully-Annotated Test</h3>
<pre>/**
 * @owner Jensen
 * @jira PROJ-5678
 */
test('Create user flow', { tag: ['@Positive'] }, async ({ request }, testInfo) => {
    setMetadata({ owner: 'Jensen', jira: 'PROJ-5678' }, testInfo);

    let user;

    await test.step('POST: Create user', async () => {
        const response = await request.post('https://reqres.in/api/users', {
            data: { name: 'Sanji', job: 'Chef' }
        });
        expect(response.ok()).toBeTruthy();
        user = await response.json();
    });

    await test.step('Validate response', async () => {
        expect(user.name).toBe('Sanji');
        expect(user.id).toBeDefined();
    });
});</pre>

  <h3>Summary</h3>
  <table>
    <tr><th>Feature</th><th>Code</th></tr>
    <tr><td>Tag test</td><td><code>{ tag: ['@Positive'] }</code></td></tr>
    <tr><td>Owner (JSDoc)</td><td><code>/** @owner Name */</code> above test</td></tr>
    <tr><td>Owner (dynamic)</td><td><code>setMetadata({ owner: 'Name' }, testInfo)</code></td></tr>
    <tr><td>Test steps</td><td><code>await test.step('Step name', async () => { ... })</code></td></tr>
    <tr><td>Attach screenshot</td><td><code>await testInfo.attach('name', { body, contentType })</code></td></tr>
  </table>

  <div class="exercise-box">
    <div class="exercise-box-header">
      <div class="exercise-icon">&#9998;</div>
      <h4>Exercise 07 &mdash; <code>training/module-07-reporting/exercises/exercise-07.spec.js</code></h4>
    </div>
    <div class="exercise-task"><strong>Task 1:</strong> Add a <code>@Positive</code> tag to an existing test</div>
    <div class="exercise-task"><strong>Task 2:</strong> Add JSDoc metadata with owner, jira, and browserstack fields</div>
    <div class="exercise-task"><strong>Task 3:</strong> Use <code>setMetadata()</code> to set owner and jira dynamically inside the test</div>
    <div class="exercise-task"><strong>Task 4:</strong> Refactor a flat test into 3 named <code>test.step()</code> blocks</div>
    <div class="exercise-task"><strong>Task 5:</strong> Write a fully annotated test combining tags, JSDoc, setMetadata, and steps</div>
  </div>
</div>

<!-- ══════════════════════════════════════════════════════════
     QUICK REFERENCE CARD
════════════════════════════════════════════════════════════ -->
<div class="page-break"></div>
<div class="module">
  <div class="module-header">
    <div class="module-num" style="background:linear-gradient(135deg,#e94560,#c0392b);">&#9733;</div>
    <div class="module-title-block">
      <h2>Quick Reference Card</h2>
      <div class="module-subtitle">All the patterns you need in one place</div>
    </div>
  </div>
  <div class="module-divider"></div>

  <div class="ref-grid">
    <div class="ref-card">
      <h4>Test Structure</h4>
<pre>const { test, expect } = require('@playwright/test');

test('name', async ({ page, request }) => {
    // ...
});

test.describe('group', () => {
    test.beforeEach(async () => { /* setup */ });
    test('name', async () => { /* test */ });
});
</pre>
    </div>
    <div class="ref-card">
      <h4>Assertions</h4>
<pre>expect(value).toBe(x)
expect(value).not.toBe(x)
expect(value).toContain('text')
expect(value).toBeDefined()
expect(value).toBeGreaterThan(0)
expect.soft(value).toBe(x)  // doesn't stop
await expect(el).toBeVisible()
await expect(el).toContainText('x')
</pre>
    </div>
    <div class="ref-card">
      <h4>API Requests</h4>
<pre>const res = await request.get(url);
const res = await request.post(url, { data });
const res = await request.put(url, { data });
const res = await request.delete(url);

res.ok()       // true if 2xx
res.status()   // e.g. 200
await res.json() // parse body
</pre>
    </div>
    <div class="ref-card">
      <h4>UI Locators</h4>
<pre>page.getByRole('button', { name: 'x' })
page.getByRole('link', { name: 'x' })
page.getByLabel('Email')
page.getByPlaceholder('Enter name')
page.getByText('Welcome')
page.locator('#id')
page.locator('.css-class')
</pre>
    </div>
    <div class="ref-card">
      <h4>Data-Driven (JSON)</h4>
<pre>const data = [{ name: 'A' }, { name: 'B' }];
test.describe('Suite', () => {
    data.forEach((d) => {
        test(\`Test \${d.name}\`, async ({ request }) => {
            // use d.name
        });
    });
});
</pre>
    </div>
    <div class="ref-card">
      <h4>Data-Driven (CSV)</h4>
<pre>const { parse } = require('csv-parse/sync');
const records = parse(
    fs.readFileSync(path.join(__dirname, 'data.csv')),
    { columns: true, delimiter: ';',
      from: 1, to: 500 }
);
for (const record of records) {
    test(record.test_case, async () => { /* */ });
}
</pre>
    </div>
    <div class="ref-card">
      <h4>Reporting</h4>
<pre>// Tags
test('name', { tag: ['@Positive'] }, ...)

// JSDoc
/** @owner Name @jira PROJ-123 */

// Dynamic
setMetadata({ owner, jira }, testInfo);

// Steps
await test.step('Step name', async () => { });
</pre>
    </div>
    <div class="ref-card">
      <h4>Helpers Pattern</h4>
<pre>// functions/helpers.js
module.exports = {
    createUser: async function(request, name) {
        const res = await request.post(url, { data: { name } });
        return await res.json();
    }
};

// In test file:
const h = require('./helpers');
const user = await h.createUser(request, 'Luffy');
</pre>
    </div>
  </div>

  <h3 style="margin-top:32px;">Environment Switching</h3>
<pre># macOS / Linux
ENV=dev npx playwright test     # development
ENV=int npx playwright test     # integration
ENV=qa  npx playwright test     # QA

# Windows PowerShell
$env:ENV="dev"; npx playwright test

# Run specific file
npx playwright test tests/api-tests.spec.js

# Run headed (see browser)
npx playwright test --headed

# Filter by test name
npx playwright test --grep "Create user"</pre>

  <div style="margin-top:40px;padding:24px;background:#f7f9fc;border-radius:10px;border:1.5px solid #c5d5e8;">
    <h3 style="border:none;margin:0 0 12px;color:#0f3460;">Resources</h3>
    <ul>
      <li><strong>Playwright docs:</strong> https://playwright.dev/docs/intro</li>
      <li><strong>Monocart Reporter:</strong> https://github.com/cenfun/monocart-reporter</li>
      <li><strong>reqres.in (practice API):</strong> https://reqres.in</li>
      <li><strong>Framework source:</strong> <code>tests/</code> and <code>functions/</code> folders</li>
    </ul>
  </div>
</div>

</body>
</html>`;

(async () => {
    const outputPath = path.join(__dirname, 'Automation-Training-Guide.pdf');

    console.log('Launching browser...');
    const browser = await chromium.launch();
    const page = await browser.newPage();

    console.log('Rendering HTML...');
    await page.setContent(html, { waitUntil: 'networkidle' });

    console.log('Generating PDF...');
    await page.pdf({
        path: outputPath,
        format: 'A4',
        printBackground: true,
        margin: {
            top: '14mm',
            bottom: '14mm',
            left: '14mm',
            right: '14mm'
        }
    });

    await browser.close();
    console.log('');
    console.log('PDF generated successfully:');
    console.log('  ' + outputPath);
})();
