# Module 07 — Reporting

## Overview

The framework uses **Monocart Reporter** to generate rich HTML test reports. Good reporting makes it easy to:
- See which tests passed/failed at a glance
- Know who owns each test
- Link tests to JIRA tickets
- Review screenshots and failure details

---

## 1. Generating the Report

Run your tests — the report is generated automatically:

```bash
npx playwright test
```

Open the report:
```bash
# After tests run, open:
test-results/report.html
```

---

## 2. Test Tags (`@Positive` / `@Negative`)

Tags classify tests and are colour-coded in the report (green for positive, red for negative):

```javascript
test('Happy path test', { tag: ['@Positive'] }, async ({ request }) => {
    // This is a positive/happy path test
});

test('Error case test', { tag: ['@Negative'] }, async ({ request }) => {
    // This tests an error condition
});
```

**See it in the framework:** All test files use `@Positive` and `@Negative` tags.

---

## 3. Metadata: Owner, JIRA, BrowserStack

### JSDoc approach (static, defined above the test)

```javascript
/**
 * @owner YourName
 * @jira PROJ-1234
 * @browserstack TC-001
 */
test('My test', async () => {
    // ...
});
```

### `setMetadata` approach (dynamic, useful in data-driven tests)

```javascript
const { setMetadata } = require('monocart-reporter');

test('My test', async ({}, testInfo) => {
    setMetadata({ owner: 'Jensen', jira: 'PROJ-1234' }, testInfo);
    // ...
});
```

Or inside a data-driven loop:

```javascript
testData.forEach((data) => {
    test(`Test: ${data.name}`, async ({}, testInfo) => {
        setMetadata({ owner: data.owner, browserstack: data.browserstack }, test.info());
        // ...
    });
});
```

> Note: Use `test.info()` (not `testInfo`) when inside a `forEach` loop.

**See it in the framework:** `tests/data-driven-tests.spec.js`

---

## 4. `test.step()` — Granular Reporting

Break your test into named steps for clearer reporting:

```javascript
test('Complete user workflow', async ({ request }) => {
    let userId;

    await test.step('Create a new user', async () => {
        const response = await request.post('https://reqres.in/api/users', {
            data: { name: 'Luffy', job: 'Pirate' }
        });
        const body = await response.json();
        userId = body.id;
        expect(body.name).toBe('Luffy');
    });

    await test.step('Verify the user was created', async () => {
        expect(userId).toBeDefined();
        console.log('Verified user ID:', userId);
    });

    await test.step('Update the user', async () => {
        const response = await request.put(`https://reqres.in/api/users/${userId}`, {
            data: { name: 'Luffy', job: 'Pirate King' }
        });
        expect(response.ok()).toBeTruthy();
    });
});
```

Steps appear as collapsible sections in the HTML report, making it easy to see exactly where a test failed.

---

## 5. Attaching Screenshots to Reports

Screenshots attached to `testInfo` appear embedded in the report:

```javascript
test('UI test with screenshot', async ({ page }, testInfo) => {
    await page.goto('https://playwright.dev/');

    const screenshot = await page.screenshot({ fullPage: true });
    await testInfo.attach('screenshot', {
        body: screenshot,
        contentType: 'image/png'
    });
});
```

**See it in the framework:** `tests/front-end-tests.spec.js`

---

## 6. Combining Everything

Here's a well-annotated test using all reporting features:

```javascript
const { test, expect } = require('@playwright/test');
const { setMetadata } = require('monocart-reporter');

/**
 * @owner Jensen
 * @jira PROJ-5678
 * @browserstack TC-042
 */
test('Create and verify user flow', { tag: ['@Positive'] }, async ({ request }, testInfo) => {
    setMetadata({ owner: 'Jensen', jira: 'PROJ-5678' }, testInfo);

    let user;

    await test.step('POST: Create user', async () => {
        const response = await request.post('https://reqres.in/api/users', {
            data: { name: 'Sanji', job: 'Chef' }
        });
        expect(response.ok()).toBeTruthy();
        user = await response.json();
    });

    await test.step('Validate response', async () => {
        expect(user.name).toBe('Sanji');
        expect(user.id).toBeDefined();
    });
});
```

---

## Summary

| Feature | Code |
|---------|------|
| Tag test | `{ tag: ['@Positive'] }` |
| Set owner (JSDoc) | `/** @owner Name */` above test |
| Set owner (dynamic) | `setMetadata({ owner: 'Name' }, testInfo)` |
| Add test steps | `await test.step('Step name', async () => { ... })` |
| Attach screenshot | `await testInfo.attach('name', { body, contentType })` |

---

## Exercise

Open `training/module-07-reporting/exercises/exercise-07.spec.js` and complete the tasks.

After running the tests, open `test-results/report.html` to see your metadata and steps in the report.

When done, compare with `exercises/solution-07.spec.js`.
