const { test, expect } = require('@playwright/test');
const { setMetadata } = require('monocart-reporter');

// ============================================================
// MODULE 07 SOLUTION — Reporting
// ============================================================

// TASK 1
test('Task 1: Tagged test', { tag: ['@Positive'] }, async ({ request }) => {
    const response = await request.get('https://reqres.in/api/users?page=1');
    expect(response.ok()).toBeTruthy();
});


// TASK 2
/**
 * @owner YourName
 * @jira TRAIN-001
 * @browserstack TC-001
 */
test('Task 2: Test with JSDoc metadata', { tag: ['@Positive'] }, async ({ request }) => {
    const response = await request.get('https://reqres.in/api/users/1');
    expect(response.ok()).toBeTruthy();
});


// TASK 3
test('Task 3: Dynamic metadata with setMetadata', { tag: ['@Positive'] }, async ({ request }, testInfo) => {
    setMetadata({ owner: 'YourName', jira: 'TRAIN-002' }, testInfo);

    const response = await request.get('https://reqres.in/api/users/2');
    expect(response.ok()).toBeTruthy();
});


// TASK 4
test('Task 4: Test with steps', { tag: ['@Positive'] }, async ({ request }) => {
    let body;

    await test.step('POST: Create user', async () => {
        const response = await request.post('https://reqres.in/api/users', {
            data: { name: 'Robin', job: 'Archaeologist' }
        });
        expect(response.ok()).toBeTruthy();
        body = await response.json();
    });

    await test.step('Validate name and job', async () => {
        expect(body.name).toBe('Robin');
        expect(body.job).toBe('Archaeologist');
    });

    await test.step('Validate ID is present', async () => {
        expect(body.id).toBeDefined();
        console.log('Created user ID:', body.id);
    });
});


// TASK 5
/**
 * @owner YourName
 * @jira TRAIN-005
 */
test('Task 5: Fully annotated test', { tag: ['@Positive'] }, async ({ request }, testInfo) => {
    setMetadata({ owner: 'YourName', jira: 'TRAIN-005' }, testInfo);

    let users;
    let createdUser;

    await test.step('GET: List users on page 2', async () => {
        const response = await request.get('https://reqres.in/api/users?page=2');
        expect(response.ok()).toBeTruthy();
        const body = await response.json();
        users = body.data;
    });

    await test.step('Validate at least 1 user exists', async () => {
        expect(users.length).toBeGreaterThan(0);
        console.log(`Found ${users.length} users on page 2`);
    });

    await test.step('POST: Create user Jinbe', async () => {
        const response = await request.post('https://reqres.in/api/users', {
            data: { name: 'Jinbe', job: 'Helmsman' }
        });
        expect(response.ok()).toBeTruthy();
        createdUser = await response.json();
    });

    await test.step('Validate created user', async () => {
        expect(createdUser.name).toBe('Jinbe');
        expect(createdUser.id).toBeDefined();
        console.log('Created:', createdUser.name, '(ID:', createdUser.id + ')');
    });
});
