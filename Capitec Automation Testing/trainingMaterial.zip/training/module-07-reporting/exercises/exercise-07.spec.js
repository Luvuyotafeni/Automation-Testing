const { test, expect } = require('@playwright/test');
const { setMetadata } = require('monocart-reporter');

// ============================================================
// MODULE 07 EXERCISE — Reporting
// ============================================================
// After running tests, open test-results/report.html to see
// your metadata and steps in the report.
//
// Run this file with:
//   npx playwright test training/module-07-reporting/exercises/exercise-07.spec.js
// ============================================================


// ------------------------------------------------------------
// TASK 1: Add tags
// The test below passes but has no tags.
// Add { tag: ['@Positive'] } to the test.
// ------------------------------------------------------------
test('Task 1: Tagged test', async ({ request }) => {
    const response = await request.get('https://reqres.in/api/users?page=1');
    expect(response.ok()).toBeTruthy();
});


// ------------------------------------------------------------
// TASK 2: Add JSDoc metadata
// Add a JSDoc comment above the test with:
//   @owner  YourName
//   @jira   TRAIN-001
//   @browserstack TC-001
// ------------------------------------------------------------
test('Task 2: Test with JSDoc metadata', { tag: ['@Positive'] }, async ({ request }) => {
    const response = await request.get('https://reqres.in/api/users/1');
    expect(response.ok()).toBeTruthy();
});


// ------------------------------------------------------------
// TASK 3: Use setMetadata dynamically
// Use setMetadata() to set owner and jira inside the test body.
// Use testInfo as the second argument (add it to the test params).
// Set owner to 'YourName' and jira to 'TRAIN-002'
// ------------------------------------------------------------
test('Task 3: Dynamic metadata with setMetadata', { tag: ['@Positive'] }, async ({ request }, testInfo) => {
    // Call setMetadata here with owner and jira

    const response = await request.get('https://reqres.in/api/users/2');
    expect(response.ok()).toBeTruthy();
});


// ------------------------------------------------------------
// TASK 4: Add test steps
// Rewrite the test below to use at least 3 test.step() blocks:
//   Step 1: 'POST: Create user'
//   Step 2: 'Validate name and job'
//   Step 3: 'Validate ID is present'
// ------------------------------------------------------------
test('Task 4: Test with steps', { tag: ['@Positive'] }, async ({ request }) => {
    const response = await request.post('https://reqres.in/api/users', {
        data: { name: 'Robin', job: 'Archaeologist' }
    });
    expect(response.ok()).toBeTruthy();

    const body = await response.json();
    expect(body.name).toBe('Robin');
    expect(body.job).toBe('Archaeologist');
    expect(body.id).toBeDefined();
});


// ------------------------------------------------------------
// TASK 5: Combine everything
// Write a complete test that:
//   - Has tag @Positive
//   - Has JSDoc: @owner YourName, @jira TRAIN-005
//   - Uses setMetadata to also set owner dynamically (overrides JSDoc)
//   - Has 3+ named steps
//   - The test flow:
//       Step 1: GET list of users on page 2
//       Step 2: Validate there is at least 1 user
//       Step 3: POST create a new user named 'Jinbe' with job 'Helmsman'
//       Step 4: Validate the created user's name
// ------------------------------------------------------------

/**
 * Add your JSDoc here
 */
test('Task 5: Fully annotated test', async ({ request }, testInfo) => {
    // Add setMetadata here

    // Write your steps here

});
