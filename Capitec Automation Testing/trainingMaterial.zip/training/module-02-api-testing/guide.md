# Module 02 — API Testing

## What is API Testing?

API testing means sending HTTP requests directly to a server (without a browser) and validating the responses. It's faster and more reliable than UI testing for checking business logic.

In Playwright, API requests are made using the `request` fixture — no extra libraries needed.

---

## 1. The `request` Fixture

To make API calls in a test, add `{ request }` to your test function parameters:

```javascript
const { test, expect } = require('@playwright/test');

test('My API test', async ({ request }) => {
    // Use 'request' to make HTTP calls
});
```

---

## 2. GET Requests

```javascript
test('GET users', async ({ request }) => {
    const response = await request.get('https://reqres.in/api/users?page=2');

    // Check the status code
    expect(response.ok()).toBeTruthy();          // status is 2xx
    expect(response.status()).toBe(200);         // exact status code

    // Parse the JSON body
    const body = await response.json();
    console.log(body);

    // Assert on the response data
    expect(body.page).toBe(2);
    expect(body.data.length).toBeGreaterThan(0);
});
```

**See it in the framework:** `tests/api-tests.spec.js`

---

## 3. POST Requests

```javascript
test('POST create user', async ({ request }) => {
    const newUser = {
        name: 'Luffy',
        job: 'Pirate'
    };

    const response = await request.post('https://reqres.in/api/users', {
        data: newUser
    });

    expect(response.ok()).toBeTruthy();

    const body = await response.json();
    console.log(body);

    expect(body.name).toBe('Luffy');
    expect(body.job).toBe('Pirate');
    expect(body.id).toBeDefined();     // id should exist
});
```

---

## 4. PUT and DELETE Requests

```javascript
test('PUT update user', async ({ request }) => {
    const response = await request.put('https://reqres.in/api/users/2', {
        data: { name: 'Zoro', job: 'Swordsman' }
    });

    expect(response.status()).toBe(200);
    const body = await response.json();
    expect(body.name).toBe('Zoro');
});

test('DELETE user', async ({ request }) => {
    const response = await request.delete('https://reqres.in/api/users/2');
    expect(response.status()).toBe(204); // 204 No Content
});
```

---

## 5. Sending Headers

Some APIs require authentication headers or content-type:

```javascript
test('POST with headers', async ({ request }) => {
    const response = await request.post('https://reqres.in/api/users', {
        headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer my-token'
        },
        data: { name: 'Sanji', job: 'Chef' }
    });

    expect(response.ok()).toBeTruthy();
});
```

**See it in the framework:** `functions/common.js` — the `DepositIntoPrimary` function shows real-world header usage.

---

## 6. Common Assertions for APIs

```javascript
const body = await response.json();

expect(response.ok()).toBeTruthy();             // 2xx status
expect(response.status()).toBe(200);            // exact status
expect(body.name).toBe('Luffy');               // exact value
expect(body.data).toHaveLength(6);             // array length
expect(body.data.length).toBeGreaterThan(0);   // at least one item
expect(body.id).toBeDefined();                 // field exists
expect(body.token).not.toBeNull();             // not null
expect(body.email).toContain('@');             // string contains
```

---

## 7. Capturing and Reusing Response Data

You can save data from one test and use it in the next (useful for chaining API calls):

```javascript
test.describe.serial('User flow', () => {
    let createdUserId;

    test('Create a user', async ({ request }) => {
        const response = await request.post('https://reqres.in/api/users', {
            data: { name: 'Luffy', job: 'Pirate' }
        });
        const body = await response.json();
        createdUserId = body.id;
        expect(createdUserId).toBeDefined();
    });

    test('Get the created user', async ({ request }) => {
        console.log('Using ID from previous test:', createdUserId);
        // Use createdUserId in the next request
    });
});
```

> **Note:** Use `test.describe.serial` (not parallel) when tests depend on each other.

---

## Summary

| Method | Playwright code |
|--------|----------------|
| GET | `request.get(url)` |
| POST | `request.post(url, { data: {...} })` |
| PUT | `request.put(url, { data: {...} })` |
| DELETE | `request.delete(url)` |
| Add headers | `request.get(url, { headers: {...} })` |
| Parse body | `await response.json()` |
| Check status | `response.status()` or `response.ok()` |

---

## Exercise

Open `training/module-02-api-testing/exercises/exercise-02.spec.js` and complete the tasks.

When done, compare with `exercises/solution-02.spec.js`.
