const { test, expect } = require('@playwright/test');

// ============================================================
// MODULE 02 EXERCISE — API Testing
// ============================================================
// We use https://jsonplaceholder.typicode.com — a free public API for testing.
// No authentication needed.
//
// Run this file with:
//   npx playwright test training/module-02-api-testing/exercises/exercise-02.spec.js
// ============================================================

const BASE_URL = 'https://jsonplaceholder.typicode.com';

// ------------------------------------------------------------
// TASK 1: Basic GET request
// Send a GET request to: https://jsonplaceholder.typicode.com/users
// Assert that:
//   - The response status is 200 (use response.ok())
//   - Verify the users is an array
//   - There is at least 1 user in the 'data' array
// ------------------------------------------------------------
test('Task 1: GET list of users', async ({ request }) => {
    // Write your code here

});


// ------------------------------------------------------------
// TASK 2: GET a single resource
// Send a GET request to: https://jsonplaceholder.typicode.com/users/3
// Assert that:
//   - The response is OK
//   - The user's id equals 3
//   - The user has an 'email' field that contains '@'
// ------------------------------------------------------------
test('Task 2: GET a single user', async ({ request }) => {
    // Write your code here

});


// ------------------------------------------------------------
// TASK 3: POST to create a resource
// Send a POST request to: https://jsonplaceholder.typicode.com/users
// with body: { name: 'Nami', job: 'Navigator' }
// Assert that:
//   - The response is OK
//   - body.name equals 'Nami'
//   - body.job equals 'Navigator'
//   - body.id is defined (not undefined)
//   - body.createdAt is defined
// ------------------------------------------------------------
test('Task 3: POST create a user', async ({ request }) => {
    // Write your code here

});


// ------------------------------------------------------------
// TASK 4: PUT to update a resource
// Send a PUT request to: https://jsonplaceholder.typicode.com/users/2
// with body: { name: 'Usopp', job: 'Sniper' }
// Assert that:
//   - The response status is 200
//   - body.name equals 'Usopp'
//   - body.updatedAt is defined
// ------------------------------------------------------------
test('Task 4: PUT update a user', async ({ request }) => {
    // Write your code here

});


// ------------------------------------------------------------
// TASK 5: Chained API calls (serial)
// Use test.describe.serial to write two linked tests:
//   Test 1 - POST to create a user, save the id to a variable
//   Test 2 - Log the id saved from Test 1 and assert it is defined
//
// Hint: declare 'let savedId;' outside the tests inside the describe block
// ------------------------------------------------------------
test.describe.serial('Task 5: Chained API tests', () => {
    // Declare your shared variable here

    test('5a: Create a user and save ID', async ({ request }) => {
        // Write your code here

    });

    test('5b: Use the saved ID', async ({ request }) => {
        // Write your code here
        // Just log the savedId and assert it is defined

    });
});
