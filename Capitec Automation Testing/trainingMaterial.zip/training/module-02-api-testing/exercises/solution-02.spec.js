const { test, expect } = require('@playwright/test');

// ============================================================
// MODULE 02 SOLUTION — API Testing
// ============================================================

const BASE_URL = 'https://jsonplaceholder.typicode.com';

// TASK 1
test('Task 1: GET list of users', async ({ request }) => {
    const response = await request.get(`${BASE_URL}/users`);

    expect(response.ok()).toBeTruthy();

    const users = await response.json();
    expect(Array.isArray(users)).toBe(true);
    expect(users.length).toBeGreaterThan(0);
});


// TASK 2
test('Task 2: GET a single user', async ({ request }) => {
    const response = await request.get(`${BASE_URL}/users/3`);

    expect(response.ok()).toBeTruthy();

    const user = await response.json();
    expect(user.id).toBe(3);
    expect(user.email).toContain('@');
});


// TASK 3
test('Task 3: POST create a post', async ({ request }) => {
    const response = await request.post(`${BASE_URL}/users`, {
        data: { name: 'Nami', job: 'Navigator' }
    });

    expect(response.status()).toBe(201);

    const body = await response.json();
    expect(body.name).toBe('Nami');
    expect(body.job).toBe('Navigator');
    expect(body.id).toBeDefined();
});


// TASK 4
test('Task 4: PUT update a user', async ({ request }) => {
    const response = await request.put(`${BASE_URL}/users/2`, {
        data: { name: 'Usopp', username: 'sniper' }
    });

    expect(response.status()).toBe(200);

    const body = await response.json();
    expect(body.name).toBe('Usopp');
    expect(body.username).toBe('sniper');
});


// TASK 5
test.describe.serial('Task 5: Chained API tests', () => {
    let savedId;

    test('5a: Create a post and save ID', async ({ request }) => {
        const response = await request.post(`${BASE_URL}/posts`, {
            data: { title: 'Robin', body: 'Archaeologist', userId: 1 }
        });

        expect(response.ok()).toBeTruthy();

        const body = await response.json();
        savedId = body.id;
        console.log('Created post with ID:', savedId);

        expect(savedId).toBeDefined();
    });

    test('5b: Use the saved ID', async ({ request }) => {
        console.log('Using ID from previous test:', savedId);
        expect(savedId).toBeDefined();
    });
});
