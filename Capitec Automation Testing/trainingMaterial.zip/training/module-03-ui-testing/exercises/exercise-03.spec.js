const { test, expect } = require('@playwright/test');

// ============================================================
// MODULE 03 EXERCISE — UI Testing
// ============================================================
// We test https://playwright.dev — no login needed.
//
// Run with:
//   npx playwright test training/module-03-ui-testing/exercises/exercise-03.spec.js
// Run headed (see browser):
//   npx playwright test training/module-03-ui-testing/exercises/exercise-03.spec.js --headed
// ============================================================


// ------------------------------------------------------------
// TASK 1: Navigate and check the title
// - Go to https://playwright.dev/
// - Assert the page title contains 'Playwright'
//   Hint: await expect(page).toHaveTitle(/Playwright/)
// ------------------------------------------------------------
test('Task 1: Navigate to Playwright homepage', async ({ page }) => {
    // Write your code here

});


// ------------------------------------------------------------
// TASK 2: Click a link and verify navigation
// - Go to https://playwright.dev/
// - Click the 'Get started' link
// - Assert that a heading with the text 'Installation' is visible
//
// See how the framework does it: tests/front-end-tests.spec.js
// ------------------------------------------------------------
test('Task 2: Click Get started and verify page', async ({ page }) => {
    // Write your code here

});


// ------------------------------------------------------------
// TASK 3: Take a screenshot and attach it to the report
// - Go to https://playwright.dev/
// - Take a full-page screenshot
// - Attach it to the test report with the label 'homepage'
//
// Hint: The test function must accept (page, testInfo) as parameters
// See: tests/front-end-tests.spec.js for the exact pattern
// ------------------------------------------------------------
test('Task 3: Screenshot the homepage', async ({ page }, testInfo) => {
    // Write your code here

});


// ------------------------------------------------------------
// TASK 4: Check multiple elements with soft assertions
// - Go to https://playwright.dev/
// - Use expect.soft() to check all of the following:
//   a) The page title contains 'Playwright'
//   b) There is a link with the name 'Get started'
//   c) There is a link with the name 'Node.js' (this one does NOT exist - it should fail)
// ------------------------------------------------------------
test('Task 4: Multiple UI assertions (soft)', async ({ page }) => {
    await page.goto('https://playwright.dev/');

    // Write your soft assertions here

});


// ------------------------------------------------------------
// TASK 5: Full navigation flow
// - Go to https://playwright.dev/
// - Click 'Get started'
// - On the next page, click the 'Introduction' link in the sidebar
// - Assert that the page heading 'Introduction' is visible
// - Take a screenshot and attach it as 'introduction-page'
// ------------------------------------------------------------
test('Task 5: Full navigation flow with screenshot', async ({ page }, testInfo) => {
    // Write your code here

});
