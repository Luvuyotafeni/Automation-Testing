const { test, expect } = require('@playwright/test');

// ============================================================
// MODULE 03 SOLUTION — UI Testing
// ============================================================

// TASK 1
test('Task 1: Navigate to Playwright homepage', async ({ page }) => {
    await page.goto('https://playwright.dev/');
    await expect(page).toHaveTitle(/Playwright/);
});


// TASK 2
test('Task 2: Click Get started and verify page', async ({ page }) => {
    await page.goto('https://playwright.dev/');
    await page.getByRole('link', { name: 'Get started' }).click();
    await expect(page.getByRole('heading', { name: 'Installation' })).toBeVisible();
});


// TASK 3
test('Task 3: Screenshot the homepage', async ({ page }, testInfo) => {
    await page.goto('https://playwright.dev/');

    const screenshot = await page.screenshot({ fullPage: true });
    await testInfo.attach('homepage', {
        body: screenshot,
        contentType: 'image/png'
    });
});


// TASK 4
test('Task 4: Multiple UI assertions (soft)', async ({ page }) => {
    await page.goto('https://playwright.dev/');

    await expect.soft(page).toHaveTitle(/Playwright/);                          // PASSES
    await expect.soft(page.getByRole('link', { name: 'Get started' })).toBeVisible(); // PASSES
    await expect.soft(page.getByRole('link', { name: 'Node.js' })).toBeVisible();     // FAILS
});


// TASK 5
test('Task 5: Full navigation flow with screenshot', async ({ page }, testInfo) => {
    await page.goto('https://playwright.dev/');
    await page.getByRole('link', { name: 'Get started' }).click();
    await page.getByRole('link', { name: 'Introduction' }).first().click();
    await expect(page.getByRole('heading', { name: 'Introduction' })).toBeVisible();

    const screenshot = await page.screenshot({ fullPage: true });
    await testInfo.attach('introduction-page', {
        body: screenshot,
        contentType: 'image/png'
    });
});
