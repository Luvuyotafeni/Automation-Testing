# Module 03 — UI Testing

## What is UI Testing?

UI (User Interface) testing automates a real browser — clicking buttons, filling in forms, navigating pages — and verifying that what appears on screen is correct.

Playwright controls real browsers (Chromium, Firefox, WebKit) and is fast and reliable.

---

## 1. The `page` Fixture

To interact with a browser in a test, add `{ page }` to your test function parameters:

```javascript
const { test, expect } = require('@playwright/test');

test('My UI test', async ({ page }) => {
    // Use 'page' to control the browser
});
```

---

## 2. Navigating to a URL

```javascript
await page.goto('https://playwright.dev/');
```

**See it in the framework:** `tests/front-end-tests.spec.js`

---

## 3. Finding Elements — Locators

Playwright provides several ways to locate elements on a page. **Prefer these in this order** (most reliable first):

### By Role (recommended)
```javascript
// Find a button with the text "Submit"
await page.getByRole('button', { name: 'Submit' }).click();

// Find a link with the text "Get started"
await page.getByRole('link', { name: 'Get started' }).click();

// Find a heading
await page.getByRole('heading', { name: 'Installation' });
```

### By Text
```javascript
await page.getByText('Welcome to Playwright').click();
```

### By Label (for form fields)
```javascript
await page.getByLabel('Email').fill('user@example.com');
```

### By Placeholder
```javascript
await page.getByPlaceholder('Enter your name').fill('Luffy');
```

### By Test ID
```javascript
// When the element has data-testid="submit-btn"
await page.getByTestId('submit-btn').click();
```

### CSS Selector (fallback)
```javascript
await page.locator('button.primary').click();
await page.locator('#username').fill('Luffy');
```

---

## 4. Interacting with Elements

```javascript
// Click
await page.getByRole('button', { name: 'Submit' }).click();

// Type into a field
await page.getByLabel('Username').fill('Luffy');

// Press a key
await page.keyboard.press('Enter');

// Select from a dropdown
await page.getByLabel('Country').selectOption('South Africa');

// Check a checkbox
await page.getByLabel('Remember me').check();

// Hover over an element
await page.getByText('Menu').hover();
```

---

## 5. Waiting for Elements

Playwright **automatically waits** for elements to appear before interacting with them. You usually don't need manual waits, but for explicit waiting:

```javascript
// Wait for an element to be visible
await expect(page.getByRole('heading', { name: 'Dashboard' })).toBeVisible();

// Wait with a custom timeout (milliseconds)
await page.getByRole('button').waitFor({ timeout: 10000 });
```

---

## 6. Assertions for UI

```javascript
// Element is visible
await expect(page.getByRole('heading', { name: 'Home' })).toBeVisible();

// Element is not visible
await expect(page.getByRole('button', { name: 'Logout' })).not.toBeVisible();

// Element contains text
await expect(page.getByRole('paragraph')).toContainText('Welcome');

// Page has the right title
await expect(page).toHaveTitle('My App');

// Page has the right URL
await expect(page).toHaveURL('https://example.com/dashboard');
```

---

## 7. Taking Screenshots

Screenshots are useful for debugging and reporting:

```javascript
test('UI test with screenshot', async ({ page }, testInfo) => {
    await page.goto('https://playwright.dev/');

    // Take a screenshot and attach it to the test report
    const screenshot = await page.screenshot({ fullPage: true });
    await testInfo.attach('screenshot', {
        body: screenshot,
        contentType: 'image/png'
    });
});
```

**See it in the framework:** `tests/front-end-tests.spec.js` — this exact pattern is used.

---

## 8. Running UI Tests in Headed Mode

By default tests run headless (no browser window). To see the browser:

```bash
npx playwright test --headed
```

---

## Summary

| Action | Code |
|--------|------|
| Go to URL | `await page.goto('https://...')` |
| Click | `await page.getByRole('button', { name: 'x' }).click()` |
| Fill input | `await page.getByLabel('x').fill('value')` |
| Assert visible | `await expect(page.getByRole('heading')).toBeVisible()` |
| Assert text | `await expect(element).toContainText('text')` |
| Take screenshot | `await page.screenshot({ fullPage: true })` |
| Run headed | `npx playwright test --headed` |

---

## Exercise

Open `training/module-03-ui-testing/exercises/exercise-03.spec.js` and complete the tasks.

When done, compare with `exercises/solution-03.spec.js`.
